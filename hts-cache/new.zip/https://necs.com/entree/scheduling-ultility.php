<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>301 Moved Permanently</title>
</head><body>
<h1>Moved Permanently</h1>
<p>The document has moved <a href="https://necs.com/entree_food_distribution_software/scheduling-ultility.php">here</a>.</p>
<hr>
<address>Apache Server at necs.com Port 443</address>
</body></html>
