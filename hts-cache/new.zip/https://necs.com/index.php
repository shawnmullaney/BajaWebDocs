﻿<!DOCTYPE html>
<html lang="en">
  <head>

<title>Food Distribution Software: Food Distribution ERP Software</title> 
	<meta name="google-site-verification" content="6EPecHT21fVP6wo7ElzmWqRsBnMYnpibOd3wJPtH0RE" />
<META NAME="KEYWORDS" CONTENT="food distribution software,wholesale distribution software,meat distribution software,seafood distribution software,warehouse management software,food distribution software quickbooks integration,affordable software for food distribution,food software">
<META NAME="Description" CONTENT="entrée Food Distribution Software: food wholesale distribution software, inventory tracking software, ERP Software, online food distribution software and more">
<meta name="DC.Title" content="www.NECS.com" />
<meta name="DC.Subject" content="food distribution software,wholesale distribution software,meat distribution software," />
<meta name="DC.Description" content="NECS Food Distribution Software" />
<meta name="DC.Coverage.PlaceName" content="Global" /> 
		
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!--meta http-equiv="X-UA-Compatible" content="IE=edge" /-->

    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="css/bootstrap.css" rel="stylesheet">


	<!-- REVOLUTION SLIDER STYLE SETTINGS-->
	<link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen" />


	 <!-- get jQuery from the google apis -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.js"></script>
    



	<!-- Modifications of StyleSheet  -->
	<link href="css/style.css" rel="stylesheet" type="text/css">

	<!-- THE ICON FONTS -->
	<link rel="stylesheet" href="css/type/fontello.css">

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="favicon.ico?v=2">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

	<!-- LOAD THE GOOGLE FONT -->
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800,400italic' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Lato:300,400,700,800,900,400italic' rel='stylesheet' type='text/css'>

<script type='text/javascript' src='swfobject.js'></script>
 <script type="text/javascript" src="polyfill/number-polyfill.js"></script> 
  </head>


<!-- ADD class="boxedlayout" IN CASE THE SITE SHOULD BE BOXED -->
  <body class="boxedlayout orange bg9">


	  	<!-- THE RESPONSIVE MENU ON THE TOP -->
		<div class="responsive_wrapper">
			<div id="responsive-menu">
				<div class="resp-closer"><i class="txt-center icon-cancel-1 white medium lm10 tm10"></i></div>
				<div class="resp-menuheader">NECS, Inc.</div>
				<ul>
                <li style="background: #f1f1f1; font-size:18px;"><a href="index.php">Homepage</a></li>
                
                <li style="background: #f1f1f1; font-size:18px;">About</li>
                <li style="background: #ffffff;"><a href="about.php">About NECS</a></li>
				<li style="background: #ffffff;"><a href="testimonials.php">Testimonials</a></li>
				<li style="background: #ffffff;"><a href="news.php">News</a></li>
                
                <li style="background: #f1f1f1; font-size:18px;">Desktop Applications</li>
                <li style="background: #ffffff;"><a href="entree/">entr&eacute;e V4</a></li>
                <li style="background: #ffffff;"><a href="ap/">entr&eacute;e.AP</a></li>
                <li style="background: #ffffff;"><a href="doc/">entr&eacute;e.DOC</a></li>
                <li style="background: #ffffff;"><a href="dot/">entr&eacute;e.DOT</a></li>
                <li style="background: #ffffff;"><a href="edi/">entr&eacute;e.EDI</a></li>
                <li style="background: #ffffff;"><a href="fs/">entr&eacute;e.FS</a></li>
                <li style="background: #ffffff;"><a href="gl/">entr&eacute;e.GL</a></li>
                <li style="background: #ffffff;"><a href="mw/">entr&eacute;e.MW</a></li>
                <li style="background: #ffffff;"><a href="ptv/">entr&eacute;e.PTV</a></li>
                <li style="background: #ffffff;"><a href="qb/">entr&eacute;e.QB</a></li>
                
                 <li style="background: #f1f1f1; font-size:18px;">Mobile Applications</li>
                 <li style="background: #ffffff;"><a href="orderpad/">Electronic Order Pad</a></li>
                 <li style="background: #ffffff;"><a href="ewm/">Electronic Warehouse Manager</a></li>
                 <li style="background: #ffffff;"><a href="dsr/">entr&eacute;e.DSR</a></li>
                 <li style="background: #f1f1f1; font-size:18px;">Internet Applications</li>
                 <li style="background: #ffffff;"><a href="net/">entr&eacute;e.NET</a></li>
                 
                 <li style="background: #f1f1f1; font-size:18px;">Websites and Catalogs</li>
                 <li style="background: #ffffff;"><a href="food-distributor-website/">entr&eacute;e.NET Website & Catalog</a></li>
                 
                  <li style="background: #f1f1f1; font-size:18px;">Support</li>
               <li style="background: #ffffff;"><a href="support/">Customer Login</a></li>
<li  style="background: #ffffff;"><a href="http://manage.necs.com" target="_blank">Pay a Bill</a></li>
<li  style="background: #ffffff;"><a href="emergency/">Emergency 24H Support</a></li>
<li style="background: #ffffff;"><a href="faq/">FAQ</a></li>
<li style="background: #ffffff;"><a href="ios13.php">iOS 13</a></li>
																<li  style="background: #ffffff;"><a href="training.php">Training</a></li>
																<li  style="background: #ffffff;"><a href="calendar.php">Event Calendar</a></li>
                                                                  <li  style="background: #ffffff;"><a href="docsearch.php">Document Samples</a></li>
																<li  style="background: #ffffff;"><a href="custom-programming.php">Custom Programming</a></li>
                                                                <li style="background: #ffffff;"><a href="remotesupport.php">Remote Support</a></li>
                  
                   <li style="background: #f1f1f1; font-size:18px;"><a href="blog.php"/>Blog</a></li>   
                    <li style="background: #f1f1f1; font-size:18px;"><a href="press.php"/>Press Release</a></li> 
                    <li style="background: #f1f1f1; font-size:18px;"><a href="partners/"/>Partners</a></li>
                    
                    <li style="background: #f1f1f1; font-size:18px;"><a href="contact.php"/>Contact</li>     
                        <li style="background: #f1f1f1; font-size:18px;"><a href="calendar.php"/>Calendar</li>    
				</ul>
			</div>
		</div>

	<!-- THIS IS THE WRAPPER FOR THE FULL TEMPLAGE -->
	<section class="boxed-wrapper">

		<!-- THE STICKY MENU AT THE TOP  -->
		<header class="header">

			<!-- THE SUB HEADER PAT -->
			 <section class="subheader_wrapper">
					<div class="container">
						<div class="subheader-left one_half nobottommargin">
							<p class="small lh35"><a href="https://www.necs.com/" /><img src="https://www.necs.com/images/256.png" width="75" style="margin-bottom: 0px; margin-top:5px; margin-right: 9px; width: 75px !important;"/></a><strong>Software for Food Distributors</strong>
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><a href="emergency/" style="color: #25a114 !important; font-size:13px !important;">ACCESS OUR EMERGENCY 24 HOUR SUPPORT</a></strong>                                
                                          
                     
						  </p>
				  </div>
                        
							<div class="subheader-right one_half lastcolumn">
							
				<div style="float: right; margin-top:2px;">		<font style="font-size:14px; font-weight:bold; font-color: #f00000; margin-right: 35px; ">Toll Free: <strong>800.766.6327</strong> &nbsp;&nbsp;&nbsp;<div class="phone-spacer"></div> Local: <strong>475.221.8200</strong></font> 	<a href="calendar.php" title="View the NECS Calendar"><img src="https://necs.com/images/cal-icon.jpg" height="26" style="height:26px !important;"/></a>			
<a href="https://www.facebook.com/pages/NECS-Inc/186969234681982" target="_blank" title="Visit the NECS, Inc. Facebook Page"><img src="images/content/socialicons/fb.jpg"></a>



&nbsp;<a href="https://www.youtube.com/channel/UC-9mkS7A5XozBMb_OBHS8_g" target="_blank"  title="Visit the NECS, Inc. Youtube Channel"><img src="images/content/socialicons/yt.jpg"></a>




<br>


</div>
						</div>
                        

						<div class="clear"></div>
                        
						<div class="divide20 visible-phone"></div>
					</div>
			</section><!-- END OF SUBHEADER WRAP -->



			<!-- THE HEADER WRAP -->
			<section class="header_wrapper">
				<div class="container" style="height: 95px !important; margin: 0px !important; margin-top: 0px !important;">
					<div class="row" >
							<!-- THE LOGO HOLDER -->
							<div class="span2" style="height: 65px !important;">
								<div class="logoholder" style="margin: 0px !important;">
									<a href="index.php"><img src="images/logo_new.png" alt="" style="max-width: none !important; height: 80px !important; margin-top: 4px !important;"></a>
								</div>
							</div>
							<!-- END OF LOGO HOLDER -->

							<!-- THE NAVIGATION HOLDER -->
							<div class="span10">
								<div id="nav" class="hidden-phone">
												<ul>
													<li><a href="index.php" class="" style="color: #000000 !important;">Home</a></li>


														<li><span class="hassubmenu toplevel"><a href="about.php"  style="color: #000000 !important;">About</a></span>
															<ul>
																<li><a href="about.php">About NECS</a></li>
                                                              
																
																<li><a href="news.php">News</a></li> 
                                                                 <li><a href="press.php">Press Release</a></li>
                                                                <li><a href="testimonials.php">Testimonials</a></li>
                                                               
															</ul>
												  </li>

														<li><span class="hassubmenu toplevel"><a href="entree/"  style="color: #000000 !important;">Products</a></span>
																																									<ul style="width: 778px !important;position:absolute; left:-200px;  min-width: 778px !important;" width="778">

<li style="width: 255px !important; float: left;" class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important;  line-height:41px !important;"><strong>Desktop Applications</strong>
</a></li>


<li style="width: 255px !important; float: left; height: 41px !important;" class="main-menu-li"><a href=""><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div>
 </a></li>


<li style="width: 255px !important; float: left;" class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important;  line-height:41px !important;"><strong>Mobile Applications</strong>
</a></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="entree_food_distribution_software/" title="Food Service Software entrée Food Distribution Software"><div class="inner-menu-item"><strong><font color="#000000">entrée V4:</font></strong></div> <br>
<span>ERP Software for Food Distributors</span></a></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="ap/" title="Food Distribution Software Accounts Payable"><div class="inner-menu-item"><strong><font color="#000000">entrée.AP:</font></strong></div><br>
<span>
Accounts Payable</a></span></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="orderpad/" title="Food Distribution Software Electronic Warehouse Manager"><div class="inner-menu-item"><strong><font color="#000000">Electronic Order Pad:</font></strong></div><br>
<span>
Order Entry & More for Your DSR's </a></span></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="doc/" title="entrée.DOC Document Scanning Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.DOC:</font></strong></div> <br>
<span>
Document Scanning</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="dot/" title="entrée.DOT Food Service Software - DOT Foods Interface"><div class="inner-menu-item"><strong><font color="#000000">entrée.DOT:</font></strong></div> <br>
<span>
The DOT Foods Interface</span></a></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="ewm/" title="Food Distribution Software Electronic Warehouse Manager"><div class="inner-menu-item"><strong><font color="#000000">Electronic Warehouse Manager:</font></strong></div><br>
<span>
Receiving, Picking & more</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="edi/" title="entrée.EDI Electronic Data Interchange"><div class="inner-menu-item"><strong><font color="#000000">entrée.EDI:</font></strong></div> <br>
<span>
EDI Solutions for your Vendors/Customers</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="fs/" title="entrée.FS Food Show Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.FS:</font></strong></div> <br>
<span>
Food Show Software</a></span></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="dsr/" title="Food Distribution Software DSR Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.DSR:</font></strong></div><br>
<span>
Laptop software for your DSRs </a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="gl/" title="entrée.GL General Ledger Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.GL:</font></strong></div> <br>
<span>General Ledger</a></span></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="mw/" title="entrée.MW Multiple Warehouse Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.MW:</font></strong></div> <br>
<span>
Multi Warehouse</a></span></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="pod/" title="Proof of Delivery" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">entrée.POD:</font></strong></div> <br>
<span>
Proof Of Delivery</a></span></li>




<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="ptv/" title="entrée.PTV Pass Through Value"><div class="inner-menu-item"><strong><font color="#000000">entrée.PTV:</font></strong></div> <br>
<span>
USDA "Pass Through Value" for Schools</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="qb/" title="entrée.QB QuickBooks Integrations Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.QB:</font></strong></div> <br>
<span>
QuickBooks Integration</a></span></li>



<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="express/" title="Food Order Entry on Mobile Devices"><div class="inner-menu-item"><strong><font color="#000000">entrée.EXPRESS:</font></strong></div><br>
<span>
Fast Order Entry on Mobile Devices</a></span></li>

<li style="width: 255px !important; float: left; " class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important; line-height:41px !important;"><strong>Website & Online Catalog</strong>
</a></li>

<li style="width: 249px !important; float: left; border-bottom: 1px solid #ededed;  height: 41px !important;"><a href="" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div> 
 </a></li>

<li style="width: 255px !important; float: left;" class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important; line-height:41px !important;"><strong>Internet Applications</strong>
</a></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="website-for-food-distributors/" title="entrée.NET Websites for Food Distributors" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">entrée.NET Website with Catalog:</font></strong></div> <br>
<span>
Quality Websites and Product Catalog</a></span></li>


<li style="width: 249px !important; float: left; border-bottom: 1px solid #ffffff;"><a href="" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div> 
 </a></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="net/" title="entrée.NET Internet Ordering Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.NET:</font></strong></div> <br>
<span>
Website/Internet Order Entry</a></span></li>
<!-- blank box
<li style="width: 249px !important; float: left; border-bottom: 1px solid #ffffff;"><a href=""><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div> 
 </a></li> -->


</ul>							</li>
<li><a href="support/" class=""  style="color: #000000 !important;">Support</a><ul  style="width: 180px !important;">
<li><a href="support/">Customer Login</a></li>
<li><a href="http://manage.necs.com" target="_blank">Pay a Bill</a></li>
<li><a href="emergency/">Emergency 24H Support</a></li>
<li><a href="faq/" target="_blank">FAQ</a></li>
<li><a href="ios13.php">iOS 13</a></li>
																<li><a href="training.php">Training</a></li>
																<li><a href="calendar.php">Event Calendar</a></li>
                                                                  <li><a href="docsearch.php">Document Samples</a></li>
																<li><a href="custom-programming.php">Custom Programming</a></li>
                                                                <li><a href="remotesupport.php">Remote Support</a></li>
															</ul></li>
<li><a href="blog.php" class=""  style="color: #000000 !important;">Blog</a></li>
		<li><a href="partners/" class=""  style="color: #000000 !important;">Partners</a></li>
														<li><a href="contact.php" class=""  style="color: #000000 !important;">Contact</a></li>
                                                        	<li><a href="calendar.php" class=""  style="color: #000000 !important;">Calendar</a></li>
                                                            
                                                            
<li><span class="hassubmenu toplevel"><a href="job-opportunities.php"  style="color: #000000 !important;">Employment</a></span>
															<ul>
																<li><a href="job-opportunities.php">Job Opportunities</a></li>
                                                  
                                                               
															</ul>
												  </li>

 <img src="images/spacer.png" width="150" style="height: 1px !important; width:150px !important;">
												</ul>
                                         
												<div class="clear"></div>

								</div><!-- END OF THE #NAV CONTAINER -->

							
							</div><!-- END OF NAVIGTION HOLDER -->
                            
						</div> <!-- END OF ROW -->
				</div> <!-- END OF CONTAINER -->
			</section> <!-- END OF HEADER WRAPPER  -->

	<div class="resp-navigator"><i class="icon-menu medium gray"></i></div>





       		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
              
	</header>

	  <div id="popup">
	  </div>
	  <div id="popup-signup">
	  </div>
	  <!-- THE CONTENT -->
	  <section class="maincontent">


		  <section class="bottomshadow">
		  </section>

		  <!-- THE BANNER CONTAINER -->
			<article class="fullwidthbanner-container " >
			  <div id="rev_slider_1_1" class="rev_slider fullwidthabanner"> 
			    <ul>
			     
                  
                   <li data-transition="3dcurtain-vertical"  data-slotamount="8" data-masterspeed="300"> <img src="images/homesliders/express.jpg">
			        <div class="caption very_big_black lfr" style="border: 1px thin solid #999999 !important;"
												 data-x="440"
												 data-y="120"
												 data-speed="300"
												 data-start="1000"
												 data-easing="easeOutExpo">entr&eacute;e.EXPRESS</div>
			        <div class="caption medium_maincolorboxed lfr"
												 data-x="440"
												 data-y="170"
												 data-speed="300"
												 data-start="1200"
												 data-easing="easeOutExpo">Mobile Order Entry<br>
		            </div>
			        <div class="caption textblock_black lfb" style="background-color: #FFFFFF; padding: 3px;"
												 data-x="440"
												 data-y="200"
												 data-speed="300"
												 data-start="1400"
												 data-easing="easeOutExpo">Fast order entry on your customers mobile device</div>
			        <div class="caption very_big_black lfr"  style="background: none !important;"
												 data-x="880"
												 data-y="30"
												 data-speed="3000"

												 data-start="1700"
												 data-easing="easeOutExpo"><img src="images/content/express/express-phone.jpg" width="80%"></div>
			    
                    <div class="caption textblock_black lfb"
										 data-x="440"
                                          data-actions='[{
 
        "event": "touch", 
        "action": "simplelink", 
        "target": "_self", 
        "url": "express/"
 
    }]'
												 data-y="235"
												 data-speed="3000"
												 data-start="1900"
												 data-easing="easeOutExpo" style="z-index: 200;">
			          <p><a title="Mobile Order Entry by NECS" class="btn btn-success btn-large" href="express/" style="z-index: 5; cursor: pointer;">Learn More</a></p>
		            </div>
		          </li>
                  
                  
			      <li data-transition="3dcurtain-vertical" data-slotamount="8" data-masterspeed="300" > <img src="images/homesliders/bgpre.jpg" alt="entree Food Distribution Software">
			        <div style="background-color:rgba(255,0,0,0.5); padding:5px;">
			          <div class="caption very_big_black lfr" style="border: 1px thin solid #999999 !important;"
												 data-x="500"
												 data-y="40"
												 data-speed="300"
												 data-start="1000"
												 data-easing="easeOutExpo">entr&eacute;e V4</div>
			          <div class="caption medium_maincolorboxed lfr"
												 data-x="500"
												 data-y="90"
												 data-speed="300"
												 data-start="1200"
												 data-easing="easeOutExpo">The Software Used by Successful Food Distributors</div>
			          <div class="caption very_big_black lfr"  style="background: none !important;"
												 data-x="490"
												 data-y="115"
												 data-speed="300"
												 data-start="1700"
												 data-easing="easeOutExpo"><img src="images/homesliders/entreeslide1.png"></div>
			          <div class="caption textblock_black lfb"
												 data-x="500"
												 data-y="410"
												 data-speed="300"
												 data-start="1400"
												 data-easing="easeOutExpo">
			            <p><a href="entree/" class="btn btn-success btn-large" title="Food Distribution Software">Learn More</a></p>
		              </div>
		            </div>
		          </li>
			      <li data-transition="3dcurtain-vertical" data-slotamount="8" data-masterspeed="300" > <img src="images/homesliders/bgnew6.jpg">
			        <div class="caption very_big_black lfr" style="border: 1px thin solid #999999 !important;"
												 data-x="20"
												 data-y="20"
												 data-speed="300"
												 data-start="1000"
												 data-easing="easeOutExpo">entrée.POD</div>
			        <div class="caption medium_maincolorboxed lfr"
												 data-x="20"
												 data-y="70"
												 data-speed="300"
												 data-start="1200"
												 data-easing="easeOutExpo">Proof of Delivery<br>
		            </div>
			        <div class="caption textblock_black lfb" style="background-color: #FFFFFF; padding: 3px;"
												 data-x="20"
												 data-y="100"
												 data-speed="300"
												 data-start="1400"
												 data-easing="easeOutExpo">The Perfect App for Error-Free Deliveries </div>
			        <div class="caption very_big_black lfr"  style="background: none !important;"
												 data-x="140"
												 data-y="110"
												 data-speed="3000"

												 data-start="1700"
												 data-easing="easeOutExpo"><img src="images/homesliders/pod-system.png"></div>
			        <div class="caption textblock_black lfb"
												 data-x="20"
												 data-y="130"
												 data-speed="3000"
												 data-start="1900"
												 data-easing="easeOutExpo">
			          <p><a href="pod/" class="btn btn-success btn-large" title="Online Food Distribution Software NECS">Learn More</a></p>
		            </div>
		          </li>
			      <li data-transition="3dcurtain-vertical" data-slotamount="8" data-masterspeed="300" > <img src="images/websites-slide.jpg">
			        <div class="caption very_big_black lfr" style="border: 1px thin solid #999999 !important;"
												 data-x="20"
												 data-y="20"
												 data-speed="300"
												 data-start="1000"
												 data-easing="easeOutExpo">Websites for Food Distributors</div>
			        <div class="caption medium_maincolorboxed lfr"
												 data-x="20"
												 data-y="70"
												 data-speed="300"
												 data-start="1200"
												 data-easing="easeOutExpo">Wow Your Customers with a Beautiful Website<br>
		            </div>
			        <div class="caption textblock_black lfb" style="background-color: #FFFFFF; padding: 3px;"
												 data-x="20"
												 data-y="100"
												 data-speed="300"
												 data-start="1400"
												 data-easing="easeOutExpo">Include Your Product Catalog, Featured Vendors & more</div>
			        <div class="caption textblock_black lfb"
												 data-x="20"
												 data-y="130"
												 data-speed="3000"
												 data-start="1900"
												 data-easing="easeOutExpo">
			          <p><a href="website-for-food-distributors/" class="btn btn-success btn-large" title="Online Websites by NECS">Learn More</a></p>
		            </div>
		          </li>
			     
                 
                 
			      <li data-transition="3dcurtain-vertical" data-slotamount="8" data-masterspeed="300" > <img src="images/homesliders/bgnew1.jpg"  alt="entree Food Distributor Software">
			        <div class="caption very_big_black lfr" style="border: 1px thin solid #999999 !important;"
												 data-x="400"
												 data-y="200"
												 data-speed="300"
												 data-start="1000"
												 data-easing="easeOutExpo">Electronic Warehouse Manager</div>
			        <div class="caption medium_maincolorboxed lfr"
												 data-x="400"
												 data-y="250"
												 data-speed="300"
												 data-start="1200"
												 data-easing="easeOutExpo">Receiving, Picking, Cycle Counts & more</div>
			        <div class="caption very_big_black lfr"  style="background: none !important;"
												 data-x="50"
												 data-y="20"
												 data-speed="3000"
												 data-start="1700"
												 data-easing="easeOutExpo"><img src="images/homesliders/ipadslide1.png"  alt="Software for Food Distribution "></div>
			        <div class="caption textblock_black lfb"
												 data-x="400"
												 data-y="280"
												 data-speed="3000"
												 data-start="1900"
												 data-easing="easeOutExpo">
			          <p><a href="ewm/" class="btn btn-success btn-large" title="Electronic Warehouse Food Distribution Software">Learn More</a></p>
		            </div>
		          </li>
			      <li data-transition="3dcurtain-vertical" data-slotamount="8" data-masterspeed="300" > <img src="images/homesliders/bgnew2.jpg">
			        <div class="caption very_big_black lfr" style="background: none !important;"
												 data-x="50"
												 data-y="90"
												 data-speed="3000"
												 data-start="1700"
												 data-easing="easeOutExpo"><img src="images/homesliders/ipadslide2.png"></div>
			        <div class="caption very_big_black lfr" style="border: 1px thin solid #999999 !important;"
												 data-x="50"
												 data-y="10"
												 data-speed="300"
												 data-start="1000"
												 data-easing="easeOutExpo">Electronic Order Pad</div>
			        <div class="caption medium_maincolorboxed lfr"
													 data-x="50"
												 data-y="60"
												 data-speed="300"
												 data-start="1200"
												 data-easing="easeOutExpo">The Mobile App to Make Your DSRs Very Happy</div>
			        <div class="caption textblock_black lfb"
												 data-x="70"
												 data-y="430"
												 data-speed="3000"
												 data-start="1900"
												 data-easing="easeOutExpo">
			          <p><a href="orderpad/" class="btn btn-success btn-large" title="DSR Software for Food Distribution Companies">Learn More</a></p>
		            </div>
		          </li>
			      <li data-transition="3dcurtain-vertical" data-slotamount="8" data-masterspeed="300" > <img src="images/homesliders/bgnew3.jpg">
			        <div class="caption very_big_black lfr" style="border: 1px thin solid #999999 !important;"
												 data-x="20"
												 data-y="20"
												 data-speed="300"
												 data-start="1000"
												 data-easing="easeOutExpo">entrée.NET</div>
			        <div class="caption medium_maincolorboxed lfr"
												 data-x="20"
												 data-y="70"
												 data-speed="300"
												 data-start="1200"
												 data-easing="easeOutExpo">Get Your Food Distribution Business ONLINE<br>
		            </div>
			        <div class="caption textblock_black lfb" style="background-color: #FFFFFF; padding: 3px;"
												 data-x="20"
												 data-y="100"
												 data-speed="300"
												 data-start="1400"
												 data-easing="easeOutExpo">Order Entry, Reporting & more for your
			          Customers & Salespeople</div>
			        <div class="caption very_big_black lfr"  style="background: none !important;"
												 data-x="140"
												 data-y="140"
												 data-speed="3000"

												 data-start="1700"
												 data-easing="easeOutExpo"><img src="images/homesliders/laptopslide1.png"></div>
			        <div class="caption textblock_black lfb"
												 data-x="20"
												 data-y="130"
												 data-speed="3000"
												 data-start="1900"
												 data-easing="easeOutExpo">
			          <p><a href="net/" class="btn btn-success btn-large" title="Online Food Distribution Software NECS">Learn More</a></p>
		            </div>
		          </li>
		        </ul>
			    <!-- <div class="tp-bannertimer"></div>-->
		      </div>
			  <script type="text/javascript">



										var revapi1;

										jQuery(document).ready(function() {

										   revapi1 = jQuery('#rev_slider_1_1').show().revolution(
											{
												delay:10000,
												startheight:400,
												startwidth:1200,


												hideThumbs:200,

												thumbWidth:100,							// Thumb With and Height and Amount (only if navigation Tyope set to thumb !)
												thumbHeight:50,
												thumbAmount:5,

												navigationType:"none",						// bullet, thumb, none
												navigationArrows:"solo",				// nexttobullets, solo (old name verticalcentered), none

												navigationStyle:"round",				// round,square,navbar,round-old,square-old,navbar-old, or any from the list in the docu (choose between 50+ different item), custom


												navigationHAlign:"center",				// Vertical Align top,center,bottom
												navigationVAlign:"bottom",					// Horizontal Align left,center,right
												navigationHOffset:0,
												navigationVOffset:20,

												soloArrowLeftHalign:"left",
												soloArrowLeftValign:"center",
												soloArrowLeftHOffset:20,
												soloArrowLeftVOffset:0,

												soloArrowRightHalign:"right",
												soloArrowRightValign:"center",
												soloArrowRightHOffset:20,
												soloArrowRightVOffset:0,

												touchenabled:"off",						// Enable Swipe Function : on/off
												onHoverStop:"on",						// Stop Banner Timet at Hover on Slide on/off

												stopAtSlide:-1,							// Stop Timer if Slide "x" has been Reached. If stopAfterLoops set to 0, then it stops already in the first Loop at slide X which defined. -1 means do not stop at any slide. stopAfterLoops has no sinn in this case.
												stopAfterLoops:-1,						// Stop Timer if All slides has been played "x" times. IT will stop at THe slide which is defined via stopAtSlide:x, if set to -1 slide never stop automatic

												hideCaptionAtLimit:0,					// It Defines if a caption should be shown under a Screen Resolution ( Basod on The Width of Browser)
												hideAllCaptionAtLilmit:0,				// Hide all The Captions if Width of Browser is less then this value
												hideSliderAtLimit:0,					// Hide the whole slider, and stop also functions if Width of Browser is less than this value

												shadow:1,								//0 = no Shadow, 1,2,3 = 3 Different Art of Shadows  (No Shadow in Fullwidth Version !)
												fullWidth:"off"							// Turns On or Off the Fullwidth Image Centering in FullWidth Modus
											});


										});	//ready

									</script>
			  <!-- END REVOLUTION SLIDER -->
	    </article>
		  <!-- END OF FULWIDTH BANNER -->

	  <section class="container topshadow">

			



			<!-- HORIZONTAL DIVIDER WITH ICON AND TEXT -->
			
			<!-- THE CONTENT SLIDER -->
					

						
				

							<div class="clear"></div>
						



						<div class="divide25"></div>


						<!-- SOME OTHER HALF CONTAINERS -->
						<section class="row">
							<section class="span6">


								<!-- HOW TO BUY -->
								<div class="divide10"></div>
								<h3 class="article-title">ERP Software for Food Distributors</h3>
							  <div class="divide5"></div>
								<p>Your <a title="Software for Food Distributors" href="entree/"><strong>foodservice distribution operation</strong></a> provides you with challenges every day. Your goal is to stay profitable without sacrificing exceptional service.  NECS understands your needs. We&rsquo;ve been developing and improving our software for the fast paced world of food distribution since 1987.<br />
<p>With 1,500 foodservice distributors running their operations with our software, we have a large base of installed clients.</p>
<p>Our <strong><a href="entree/">entr&eacute;e</a></strong>  line of Windows based, foodservice  distribution software has  everything your operation needs to be successful and  profitable.&nbsp;</p>
<p>It&rsquo;s ideal for everything from full line distributors, to those specializing in meat, produce, cheese, seafood, dairy and beverage distribution, as well as food importers / exporters.</p>
<p>If you are looking for a proven, user friendly food  distribution  system that will bring your wholesale food distribution operation  to  the next level&hellip; look no further than NECS!</p></p>
								<div class="divide20"></div>
							<a href="entree/" style="color: #ffffff !important;" title="Food Distribution Software entree from NECS">	<button class="btn maincolor witharrow large nobreak">See All Features</button></a><!-- END OF HOW TO BUY -->
<div class="divide20"></div>
<font style="font-size:16px;"><a href="entree/" title="Food Distribution Software from NECS">entr&eacute;e</a> </font> &nbsp; &nbsp; &nbsp;
<h1 style="display:inline; font-size:24px;"><a href="entree/" title="Food Distribution Software NECS">Food Distribution Software</a></h1>&nbsp; &nbsp; &nbsp;
<h1 style="display:inline;  font-size:17px;"><a href="website-for-food-distributors/" title="Websites for Food Distributors">Websites For Food Distributors</a></h1> &nbsp; &nbsp; &nbsp;
<font style="font-size:12px;"><a href="entree/" title="Inventory Control Food Distribution Software">Inventory Control</a></font> &nbsp; &nbsp; &nbsp;
<font style="font-size:16px;"><a href="entree/" title="NECS Food Distribution Software">Food Software</a></font>  &nbsp; &nbsp; &nbsp;
<font style="font-size:19px;"><a href="orderpad/" title="Electronic Order Pad Food Distribution Software">Electronic Order Pad</a></font> &nbsp; &nbsp; &nbsp;
<h1 style="display:inline; font-size:14px;"><a href="eop/" title="Mobile Electronic Warehouse Manager">Electronic Warehouse Manager</a></h1> &nbsp; &nbsp; &nbsp;
<h1 style="display:inline; font-size:19px;"><a href="dsr/" title="DSR Food Distribution Software">DSR Software</a></h1> &nbsp; &nbsp; &nbsp;
<font style="font-size:15px;"><a href="net/" title="Online Ordering Food Software">Online Ordering</a></font> &nbsp; &nbsp; &nbsp;
<font style="font-size:18px; line-height:2.5;"><a href="entree/" title="ERP Food Software">ERP Software</a></font> &nbsp; &nbsp; &nbsp;
<font style="font-size:15px;"><a href="entree/" title="Online Product Catalog">Online Product Catalog</a></font> &nbsp; &nbsp; &nbsp;
<font style="font-size:12px;"><a href="entree/" title="Sybase Advantage SQL">Sybase Advantage SQL</a></font> &nbsp; &nbsp; &nbsp;
<font style="font-size:15px;"><a href="entree/" title="Software for Food Distributors">Software for Food Distributors</a></font> &nbsp; &nbsp; &nbsp;
<font style="font-size:18px;"><a href="ap/" title="Accounts Payable Software">Accounts Payable</a></font> &nbsp; &nbsp; &nbsp;
								<div class="divide40"></div>

						</section>

						<section class="span5 offset1">
								<h3 class="article-title">NECS News:</h3>

								<div class="divide15"></div>

								<!-- THE FEATURED ARTICLE SLIDER -->
								<article class="featured-article-horslider">
                                 
							<article class="blogpost">
								<!-- TABLE VIEW FOR BLOG POST -->


									<h2 class="blog-title" style="margin-bottom: 0px; padding-bottom: 0px;"><a title="Version 4.4.1.1 of entrée is now available!" href="news-article.php?id=344">Version 4.4.1.1 of entrée is now available!</a></h2>
									
									<!-- BLOG ATTRIBUTES -->
										<div class="verysmall gray leftfloat rm2 bm2" style="margin-bottom: 0px; padding: 0px;"><i class="icon-calendar small  rm10"></i><strong>Jul 13 2020</strong></div>
					
										<div class="clear"></div>
                                        <hr style="margin: 0px; padding: 0px;">
                                        
                                
							<article class="blogpost">
								<!-- TABLE VIEW FOR BLOG POST -->


									<h2 class="blog-title" style="margin-bottom: 0px; padding-bottom: 0px;"><a title="New Blog Post: entrée Dashboards" href="news-article.php?id=342">New Blog Post: entrée Dashboards</a></h2>
									
									<!-- BLOG ATTRIBUTES -->
										<div class="verysmall gray leftfloat rm2 bm2" style="margin-bottom: 0px; padding: 0px;"><i class="icon-calendar small  rm10"></i><strong>Jul 02 2020</strong></div>
					
										<div class="clear"></div>
                                        <hr style="margin: 0px; padding: 0px;">
                                        
                                
							<article class="blogpost">
								<!-- TABLE VIEW FOR BLOG POST -->


									<h2 class="blog-title" style="margin-bottom: 0px; padding-bottom: 0px;"><a title="Version 4.4.0.2 of entrée is now available!" href="news-article.php?id=341">Version 4.4.0.2 of entrée is now available!</a></h2>
									
									<!-- BLOG ATTRIBUTES -->
										<div class="verysmall gray leftfloat rm2 bm2" style="margin-bottom: 0px; padding: 0px;"><i class="icon-calendar small  rm10"></i><strong>May 19 2020</strong></div>
					
										<div class="clear"></div>
                                        <hr style="margin: 0px; padding: 0px;">
                                        
                                
							<article class="blogpost">
								<!-- TABLE VIEW FOR BLOG POST -->


									<h2 class="blog-title" style="margin-bottom: 0px; padding-bottom: 0px;"><a title="Version 4.4.0.1 of entrée is now available!" href="news-article.php?id=340">Version 4.4.0.1 of entrée is now available!</a></h2>
									
									<!-- BLOG ATTRIBUTES -->
										<div class="verysmall gray leftfloat rm2 bm2" style="margin-bottom: 0px; padding: 0px;"><i class="icon-calendar small  rm10"></i><strong>May 13 2020</strong></div>
					
										<div class="clear"></div>
                                        <hr style="margin: 0px; padding: 0px;">
                                        
     <a href="news.php" title="News from NECS Food Distribution Software">View All News</a>  <br><br>	<article class="newsletter gray-boxed" style="max-width:428px !important; background-color: #cccccc !important;">
									<h3 class="blog-title nobottommargin">Join Our Email List</h3>
									<div class="divide5"></div>
									<i class="smalL">Enter your email address below to receive information about software updates, new features, new products and other important correspondence.  Your email address is kept private and you can opt out at any time.</i>
									<div class="divide10"></div>
								<form action="//necs.us13.list-manage.com/subscribe/post?u=63b2f13f55d76e665ec3199b6&amp;id=84facb669b" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" target="_blank" >
										<input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL" placeholder="Email Address">

										<div class="divide10"></div>
                                       <i class="smalL red bold"> Please type "NECS" to help fight spam:</i> <input type="text" value="" name="necs">

										<div class="divide10"></div>
										<div class="txt-left">
											<input type="submit" class="btn maincolor small" value="Sign Up">
										</div>
									</form>
								</article>



								</article>

								<div class="divide30"></div>

								
							</section><!-- END OF SPAN5 -->



						</section><!-- END OF ROW -->

					


						<!-- THE CONTENT SLIDER -->
						<article>

							<!-- TEASER NAVIGATION -->
						

							<div class="clear"></div>
							

							<!-- SHOWBIZ PRO CONTAINER -->
							<section class="showbiz-container">

									<!-- END OF TEASER NAVIGATION -->


									<!--	THE PORTFOLIO ENTRIES	-->
									<div class="showbiz-teaser" data-left="#teaser_left_50afa281c1191" data-right="#teaser_right_50afa281c1191">
												<div class="overflowholder">
													<ul>
														<!-- AN ENTRY HERE -->
														<li>
																	<div class="mediaholder">
																		<a href="entree/inventory-control.php" title="Distribution ERP Software"><img alt="" src="images/homesliders/smallsliders/bg1.jpg"></a>
																	

																	</div>
																	<div class="detailholder">
																		<h4 class="showbiz-title txt-center nobottommargin"><a href="entree/inventory-control.php" title="Easy Software for Food Distribution Operations" class="black">entrée V4 SQL:
Cycle Counts</a></h4>
																		<div class="divide5"></div>
																		<p class="txt-center" style="color: #f00000;">The Preferred Method To Count Your Inventory</p>
<p class="txt-center"><em>New Cycle Count Feature Uses ABC Analysis To Streamline Your Inventory Control</em></p>
																	</div>
														</li>
       <!-- AN ENTRY HERE -->
														<li>
																	<div class="mediaholder">
																	<a href="entree/index.php" title="Food Distribution Software for your small business"><img alt="" src="images/homesliders/smallsliders/bg5.jpg"></a>
																	

																	</div>
	<div class="detailholder">
																		<h4 class="showbiz-title txt-center nobottommargin"><a href="entree/index.php" class="black" title="entree v4 Food Distribution Software">entrée V4 SQL:
Sybase Advantage SQL</a></h4>
																		<div class="divide5"></div>
																		<p class="txt-center" style="color: #f00000;">entrée V4 SQL Upgrades Your Databases To SQL
And A True Client/Server Model
</p>
<p class="txt-center"><em>Sybase Delivers Rock Solid Database Integrity With Amazing Speed</em></p>
																	</div>

													
														</li>
														<!-- AN ENTRY HERE -->
														<li>
																	<div class="mediaholder">
																	<a href="entree/dashboards.php" title="NECS Software for Food Distributors"><img alt="" src="images/homesliders/smallsliders/bg3.jpg"></a>
																	

																	</div>
	<div class="detailholder">
																		<h4 class="showbiz-title txt-center nobottommargin"><a href="entree/dashboards.php" class="black" title="Dashboards Food Distribution Software">entrée V4 SQL:
Dashboards</a></h4>
																		<div class="divide5"></div>
																		<p class="txt-center" style="color: #f00000;">Visualize Your Data
</p>
<p class="txt-center"><em>Business Intelligence To Understand Your Complex Data And Trends</em></p>
																	</div>

														</li>

													
                                                        
                                                 



													</ul>
													<div class="clear"></div>
												</div> <!-- END OF OVERFLOWHOLDER -->
												<div class="clear"></div>
											</div>
									</section> <!-- END OF SHOWBIZ PRO CONTAINER -->
						</article>
                        
                        
                        
						<!-- THE CONTENT SLIDER -->
						<article>

							<!-- TEASER NAVIGATION -->
							
							<div class="clear"></div>
							<div class="divide30"></div>

							<!-- SHOWBIZ PRO CONTAINER -->
							<section class="showbiz-container">

									<!-- END OF TEASER NAVIGATION -->


									<!--	THE PORTFOLIO ENTRIES	-->
									<div class="showbiz-teaser" data-left="#teaser_left_50afa281c1191" data-right="#teaser_right_50afa281c1191">
												<div class="overflowholder">
													<ul>
													

														<!-- AN ENTRY HERE -->
														<li>
																	<div class="mediaholder">
																	<a href="entree/search-screen.php" title="Search Screens entree Food Software"><img alt="" src="images/homesliders/smallsliders/bg2.jpg"></a>
																	

																	</div>
	<div class="detailholder">
																		<h4 class="showbiz-title txt-center nobottommargin"><a href="entree/search-screen.php" class="black" title="Software for Food Distributors from NECS">entrée V4 SQL:
Enhanced Search Screens</a></h4>
																		<div class="divide5"></div>
																		<p class="txt-center" style="color: #f00000;">Find Data Faster With New Search Screens
</p>
<p class="txt-center"><em>Enhanced Searching Helps You Find What You Need Faster</em></p>
																	</div>

														</li>

													<!-- AN ENTRY HERE -->
														<li>
																	<div class="mediaholder">
																	<a href="entree/scheduling-ultility.php" title="Automatic Scheduling Food Software"><img alt="" src="images/homesliders/smallsliders/bg4.jpg"></a>
																	

																	</div>
	<div class="detailholder">
																		<h4 class="showbiz-title txt-center nobottommargin"><a href="entree/scheduling-ultility.php" title="Food Distribution Software for PC" class="black">entrée V4 SQL:
Scheduling Utility</a></h4>
																		<div class="divide5"></div>
																		<p class="txt-center" style="color: #f00000;">Use entrée More Efficiently With New
Scheduling Features
</p>
<p class="txt-center"><em>Save Time And Human Resources By Automating Report Scheduling & More</em></p>
																	</div>

													
														</li>
                                                        
                                                 <li>
                                              
                                                 </li>



													</ul>
													<div class="clear"></div>
												</div> <!-- END OF OVERFLOWHOLDER -->
												<div class="clear"></div>
											</div>
									</section> <!-- END OF SHOWBIZ PRO CONTAINER -->
						</article>


						<div class="divide5"></div>


		

						<div class="divide60"></div>

		</section><!-- END OF CONTAINER -->


 	</section> <!-- END OF MAIN CONTENT HERE -->

		<footer>
			<section class="footer">
				<!-- A SPECIAL FOOTER FOR 4 - 8 SPAN LEFT SIDE !! -->

				
			  <div class="container" style="background-color: #cccccc;">
					<div class="row">

						<!-- SIMPLE ABOUT TEXT BLOCK -->
						<article class="span3">
						<h3 class="widget-title nobottommargin"><img src="images/logo_new.png" /></h3>
							<div class="divide10"></div>
							<p>NECS began in 1987 with the sole mission to produce top quality software for foodservice distributors.  Distributors who run their operations with our Windows based <strong>entr&eacute;e</strong> software are more profitable and operate more efficiently on reduced staffs. We have an enthusiastic user base who readily recommend <strong>entr&eacute;e</strong> to other wholesale food distributors.</p>
					  </article>

						<!-- ADDRESS BLOCK WIDGET-->
						<article class="span2">
							<h3 class="widget-title nobottommargin">GET IN TOUCH</h3>
							<div class="divide30"></div>
							<div class="table nobottommargin">
								<div class="table-cell top"><i class="icon-location-1 small black"></i></div>
								<div class="table-cell">
									<h3 class="widget-title">ADDRESS</h3>
										<p class="small italic">322 East Main Street<br />

3rd Floor<br />

Branford, CT. 06405</p>
							
								</div>
							</div>

							<div class="divide25"></div>
							<div class="table">
								<div class="table-cell top"><i class="icon-mobile small black"></i></div>
								<div class="table-cell">
									<h3 class="widget-title">PHONE</h3>
                                    <table width="100%" style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
                                    <tr>
                                    <td width="36%" style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
									<p class="small italic">Toll Free:</p></td><td width="64%"  style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" ><p class="small italic"> 800.766.6327</p>
                                    </td>
                                    </tr>
                                    <tr>
                                    <td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
                                    <p class="small italic">Local:</p></td><td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" ><p class="small italic">475.221.8200</p>
                                    </td>
                                   </tr>
                                   <tr>
                                   <td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
                                    <p class="small italic">Fax:</p></td><td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" > <p class="small italic">203.208.0889</p>
                                    </td>
                                    </tr>
                                    </table>
								</div>
							</div>
<a href="http://www.softwareadvice.com/erp/necs-entree-profile/" target="_blank" add rel="nofollow" ><img src="images/5.png"width="150" height="100" alt="Software Advice Reviews of NECS entr�e Software" /></a>
						</article><!-- END OF ADDRESS BLOCK WIDGET -->

						<!-- THE RECENT POSTS WIDGET -->
						<article class="span3">
							<h3 class="widget-title nobottommargin"><a href="blog.php">RECENT POSTS</a></h3>
							<div class="divide30"></div>

							<!-- A RECENT POSTS -->
							<section class="recent-posts-wrapper">
                            
                              
								<!-- A RECENT POST -->
								<div class="recent-post">
									<h4 class="recent-post-title nobottommargin"><a href="blog-article.php?id=49"><strong>entrée Dashboards</strong></a></h4>
									<div class="divide5"></div>
									<span class="small italic postdate">Jul 02 2020</span>
								</div><!-- END OF RECENT POST -->

								<div class="divide30"></div>
 
								<!-- A RECENT POST -->
								<div class="recent-post">
									<h4 class="recent-post-title nobottommargin"><a href="blog-article.php?id=48"><strong>Quantum Physics, the Mandela Effect and perceived changes to your entree data</strong></a></h4>
									<div class="divide5"></div>
									<span class="small italic postdate">Jun 03 2019</span>
								</div><!-- END OF RECENT POST -->

								<div class="divide30"></div>
 
								<!-- A RECENT POST -->
								<div class="recent-post">
									<h4 class="recent-post-title nobottommargin"><a href="blog-article.php?id=46"><strong>NECS, Inc. Launches entrée.EXPRESS Mobile Ordering App</strong></a></h4>
									<div class="divide5"></div>
									<span class="small italic postdate">Jul 19 2018</span>
								</div><!-- END OF RECENT POST -->

								<div class="divide30"></div>
  
								

							</section><!-- END OF RECENT POSTS WRAPPER -->



						</article><!-- END OF RECENT POSTS FOOTER WIDGET-->

						<article class="span4">
							<h3 class="widget-title nobottommargin"><a href="http://www.youtube.com/necsentreesoftware">ENTR&Eacute;E V4 SQL: THE LATEST GENERATION IN FOOD DISTRIBUTION SOFTWARE</a></h3>
							<div class="divide10"></div>
							<ul class="flickr feed"></ul>
												  <iframe width="335" height="315" src="//www.youtube.com/embed/zslV6Dpc6tQ" frameborder="0" allowfullscreen></iframe>
						</article>
					</div>
				</div>
			</section>


			<section class="subfooter">
				<div class="container">
					<div class="two_third">
						<p class="small">  <strong>Quick Nav: </strong><br />
						  <a  style="color: #cccccc !important;"  href="index.php" title="NECS Food Software for Distributors">Home</a> | <a  style="color: #cccccc !important;"  href="about.php" title="Food Distributor Software from NECS">About</a> | <a  style="color: #cccccc !important;"  href="testimonials.php" title="NECS ERP Software">Testimonials</a> | <a  style="color: #cccccc !important;"  href="news.php">News</a> | <a  style="color: #cccccc !important;"  href="blog.php">Blog</a> | <a  style="color: #cccccc !important;"  href="contact.php">Contact</a> | <a  style="color: #cccccc !important;"  href="support/">Support Login</a> | <a  style="color: #cccccc !important;"  href="training.php">Training</a><br />
						  <a  style="color: #cccccc !important;"  href="calendar.php">Event Calendar</a> | <a  style="color: #cccccc !important;"  href="docsearch.php">Document Samples</a> | <a  style="color: #cccccc !important;"  href="remotesupport.php">Remote Support</a> | <a  style="color: #cccccc !important;"  href="custom-programming.php">Custom Programming</a><br />
<br />

     <strong>Products: </strong><br />

    <a href="entree_food_distribution_software/" title="entr&eacute;e Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e V4</a> | 
      
    
     
     <a href="ap/" title="entr&eacute;e.AP - Accounts Payable - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.AP</a> |  
      
    
     
      <a href="doc/" title="entr&eacute;e.DOC - Document Scanning Software - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.DOC</a> |  
          
    
        
      <a href="dot/" title="DOT Foods Interface Software" style="color: #cccccc !important;">entr&eacute;e.DOT</a> |  
      
    
     
      <a href="dsr/" title="entr&eacute;e.DSR - Salesperson Sofware - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.DSR</a> |  
      
    
     
      <a href="edi/" title="entr&eacute;e.EDI - Communication Software for the Food Industry" style="color: #cccccc !important;">entr&eacute;e.EDI</a> |  
      
       <a href="express/" title="entr&eacute;e.EXPRESS" style="color: #cccccc !important;">entr&eacute;e.EXPRESS</a> |
     
      <a href="fs/" title="entr&eacute;e.FS - Food Show Software for the Food Industry" style="color: #cccccc !important;">entr&eacute;e.FS</a> |  
      
    
     
      <a href="gl/" title="entr&eacute;e.GL - General Ledger Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.GL</a> |  
      
    
     
      <a href="mw/" title="entr&eacute;e.MW - Software for Organic Food Distributors" style="color: #cccccc !important;">entr&eacute;e.MW</a><br /> 
      
    
     
      <a href="net/" title="entr&eacute;e.NET - Food Distribution Website" style="color: #cccccc !important;">entr&eacute;e.NET</a> |  
      
    
     
      <a href="ptv/" title="Pass Through Value - Software for Food Distributors" style="color: #cccccc !important;">entr&eacute;e.PTV</a> |  
      
    
     
      <a href="qb/" title="entr&eacute;e.QB - Quickbooks Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.QB</a> |  
      
    
     
      <a href="upc/" title="Barcode Scanning - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.UPC</a> |  
      
    
            
        <a href="orderpad/" title="Electronic Order Pad, iPad Order Entry Application, Mobile order entry" style="color: #cccccc !important;">Electronic Order Pad</a> |  
        
    
                  
        <a href="ewm/" title="Electronic Warehouse Manager" style="color: #cccccc !important;">Electronic Warehouse Manager</a></p>
				  </div>

		

					<div class="one_third lastcolumn">
				<div class="rightfloat">
				  <!-- SOCIALS -->          

<p class="small" >
C 2018 NECS, Inc. All Rights Reserved.<br />

<a href="sitemap.php" title="NECS.com Sitemap" style="color: #CCCCCC !important;">Sitemap</a>
					
	</p>
<a href="http://www.softwareadvice.com/erp/necs-entree-profile/" target="_blank" add rel="nofollow" ><img src="../images/content/01-gray-see-reviews.png" width="125" style="margin-top:7px; border: 2px solid #000 !important;"></a></div>
					</div>
					<div class="clear"></div>
				</div>
			</section>

		</footer>
	</section><!-- THE END OF THE BOXED WRAPPER -->

    <!-- javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

	<!-- Load the Bootstrap JS files -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

	<!-- Swipe Function on the 2nd Gallery in Home.html -->
	<script type="text/javascript" src="js/jquery.overscroll.min.js"></script>

	<!-- Basic ThemePunch Plugin Helpers -->
	<script type="text/javascript" src="js/jquery.themepunch.plugins.min.js"></script>

	<!-- INCLUDE THE MEGAFOLIO BANNER -->
	<!--<script type="text/javascript" src="megafolio/js/jquery.themepunch.megafoliopro.js"></script>-->

	<!-- FANCYBOX FOR MEGAFOLIO -->
<!--	<script type="text/javascript" src="megafolio/fancybox/jquery.fancybox.pack.js?v=2.1.3"></script>-->

	<!-- Optionally add helpers - button, thumbnail and/or media ONLY FOR ADVANCED USAGE-->
<!--	<script type="text/javascript" src="megafolio/fancybox/helpers/jquery.fancybox-media.js?v=1.0.5"></script>-->

	<!-- INCLUDE THE SHOWBIZ SCRIPT HERE -->
	<script type="text/javascript" src="js/jquery.themepunch.showbizpro.js"></script>

	<!-- TWITTER INCLUDS -->
	<script type="text/javascript" src="js/twitter.min.js"></script>

	<!-- SCROLLPLANE IMPORT -->
	<script type="text/javascript" src="js/jquery.jscrollpane.min.js"></script>

	<!-- the mousewheel plugin - optional to provide mousewheel support -->
	<script type="text/javascript" src="js/jquery.mousewheel.js"></script>

	<script type="text/javascript" src="js/jquery.fh.portfolio.js"></script>

	<!-- GOOGLE MAP -->
	<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=false"></script>
	<script type="text/javascript" src="js/jquery.gmap.js"></script>

	<!-- RETINA READY FUNCTIONS IN HTML DOCUMENTS -->
	<script type="text/javascript" src="js/retina.js" ></script>

	<!-- MEDIA RESIZERS -->
	<script type='text/javascript' src='js/mediaelement-and-player.min.js'></script>
	<script type='text/javascript' src='js/FitVids.js'></script>

	<!-- SOCIAL HELPERS -->
	<script type="text/javascript" src="js/jquery.jribbble-0.11.0.ugly.js" ></script>
	<script type="text/javascript" src="js/jquery.dcflickr.1.0.js" ></script>

	<!-- FORMS FOR CONTACT -->
	<script type="text/javascript" src="js/forms.js" ></script>

	<!-- MAIN FUNCTIONS FOR THEME -->
	<script type="text/javascript" src="js/screen.js" ></script>
    	<!-- INCLUDE THE REVOLUTION SLIDER -->
	<script type="text/javascript" src="js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>



<script type="text/javascript">
//<![CDATA[
var DID=177460;
var pcheck=(window.location.protocol == "https:") ? "https://sniff.visistat.com/live.js":"http://stats.visistat.com/live.js";
document.writeln('<scr'+'ipt src="'+pcheck+'" type="text\/javascript"><\/scr'+'ipt>');
//]]>
</script>
<!--VISISTAT SNIPPET//-->


<script src="https://www.google-analytics.com/urchin.js"
type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-426634-1";
urchinTracker();
</script><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-15123112-14']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
  </body>
</html>
