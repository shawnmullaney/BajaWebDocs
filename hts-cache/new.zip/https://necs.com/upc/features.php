<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>


<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Barcode Scanning Software - Food Inventory Software</title>
<META NAME="KEYWORDS" CONTENT="food distribution software,food industry software,food inventory software,food distribution online,food distribution accounts payable software,food distribution software quickbooks integration,affordable software for food distributors">
<META NAME="Description" CONTENT="entrée.UPC - Barcode Scanning Software for Food Distribution">
  <SCRIPT TYPE="text/javascript" SRC="../slideshow.js">
</SCRIPT>
<SCRIPT TYPE="text/javascript" SRC="playlist.js"></SCRIPT>
	</head><body><div align="center">
<div id="container">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!--meta http-equiv="X-UA-Compatible" content="IE=edge" /-->

    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="css/bootstrap.css" rel="stylesheet">


	<!-- REVOLUTION SLIDER STYLE SETTINGS-->
	<link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen" />


	 <!-- get jQuery from the google apis -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.js"></script>
    



	<!-- Modifications of StyleSheet  -->
	<link href="css/style.css" rel="stylesheet" type="text/css">

	<!-- THE ICON FONTS -->
	<link rel="stylesheet" href="css/type/fontello.css">

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="favicon.ico?v=2">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

	<!-- LOAD THE GOOGLE FONT -->
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800,400italic' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Lato:300,400,700,800,900,400italic' rel='stylesheet' type='text/css'>

