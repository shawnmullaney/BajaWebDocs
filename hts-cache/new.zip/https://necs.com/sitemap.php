<!DOCTYPE html>
<html lang="en">
  <head>

    <title>Sitemap: NECS Food Distribution Software</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!--meta http-equiv="X-UA-Compatible" content="IE=edge" /-->

    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="css/bootstrap.css" rel="stylesheet">


	<!-- REVOLUTION SLIDER STYLE SETTINGS-->
	<link rel="stylesheet" type="text/css" href="js/rs-plugin/css/settings.css" media="screen" />


	 <!-- get jQuery from the google apis -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.js"></script>
    



	<!-- Modifications of StyleSheet  -->
	<link href="css/style.css" rel="stylesheet" type="text/css">

	<!-- THE ICON FONTS -->
	<link rel="stylesheet" href="css/type/fontello.css">

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="favicon.ico?v=2">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

	<!-- LOAD THE GOOGLE FONT -->
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800,400italic' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Lato:300,400,700,800,900,400italic' rel='stylesheet' type='text/css'>

<script type='text/javascript' src='swfobject.js'></script>
 <script type="text/javascript" src="polyfill/number-polyfill.js"></script> 
  </head>


<!-- ADD class="boxedlayout" IN CASE THE SITE SHOULD BE BOXED -->
  <body class="boxedlayout orange bg9">


	  	<!-- THE RESPONSIVE MENU ON THE TOP -->
		<div class="responsive_wrapper">
			<div id="responsive-menu">
				<div class="resp-closer"><i class="txt-center icon-cancel-1 white medium lm10 tm10"></i></div>
				<div class="resp-menuheader">NECS, Inc.</div>
				<ul>
                <li style="background: #f1f1f1; font-size:18px;"><a href="index.php">Homepage</a></li>
                
                <li style="background: #f1f1f1; font-size:18px;">About</li>
                <li style="background: #ffffff;"><a href="about.php">About NECS</a></li>
				<li style="background: #ffffff;"><a href="testimonials.php">Testimonials</a></li>
				<li style="background: #ffffff;"><a href="news.php">News</a></li>
                
                <li style="background: #f1f1f1; font-size:18px;">Desktop Applications</li>
                <li style="background: #ffffff;"><a href="entree/">entr&eacute;e V4</a></li>
                <li style="background: #ffffff;"><a href="ap/">entr&eacute;e.AP</a></li>
                <li style="background: #ffffff;"><a href="doc/">entr&eacute;e.DOC</a></li>
                <li style="background: #ffffff;"><a href="dot/">entr&eacute;e.DOT</a></li>
                <li style="background: #ffffff;"><a href="edi/">entr&eacute;e.EDI</a></li>
                <li style="background: #ffffff;"><a href="fs/">entr&eacute;e.FS</a></li>
                <li style="background: #ffffff;"><a href="gl/">entr&eacute;e.GL</a></li>
                <li style="background: #ffffff;"><a href="mw/">entr&eacute;e.MW</a></li>
                <li style="background: #ffffff;"><a href="ptv/">entr&eacute;e.PTV</a></li>
                <li style="background: #ffffff;"><a href="qb/">entr&eacute;e.QB</a></li>
                
                 <li style="background: #f1f1f1; font-size:18px;">Mobile Applications</li>
                 <li style="background: #ffffff;"><a href="orderpad/">Electronic Order Pad</a></li>
                 <li style="background: #ffffff;"><a href="ewm/">Electronic Warehouse Manager</a></li>
                 <li style="background: #ffffff;"><a href="dsr/">entr&eacute;e.DSR</a></li>
                 <li style="background: #f1f1f1; font-size:18px;">Internet Applications</li>
                 <li style="background: #ffffff;"><a href="net/">entr&eacute;e.NET</a></li>
                 
                 <li style="background: #f1f1f1; font-size:18px;">Websites and Catalogs</li>
                 <li style="background: #ffffff;"><a href="food-distributor-website/">entr&eacute;e.NET Website & Catalog</a></li>
                 
                  <li style="background: #f1f1f1; font-size:18px;">Support</li>
               <li style="background: #ffffff;"><a href="support/">Customer Login</a></li>
<li  style="background: #ffffff;"><a href="http://manage.necs.com" target="_blank">Pay a Bill</a></li>
<li  style="background: #ffffff;"><a href="emergency/">Emergency 24H Support</a></li>
<li style="background: #ffffff;"><a href="faq/">FAQ</a></li>
<li style="background: #ffffff;"><a href="ios13.php">iOS 13</a></li>
																<li  style="background: #ffffff;"><a href="training.php">Training</a></li>
																<li  style="background: #ffffff;"><a href="calendar.php">Event Calendar</a></li>
                                                                  <li  style="background: #ffffff;"><a href="docsearch.php">Document Samples</a></li>
																<li  style="background: #ffffff;"><a href="custom-programming.php">Custom Programming</a></li>
                                                                <li style="background: #ffffff;"><a href="remotesupport.php">Remote Support</a></li>
                  
                   <li style="background: #f1f1f1; font-size:18px;"><a href="blog.php"/>Blog</a></li>   
                    <li style="background: #f1f1f1; font-size:18px;"><a href="press.php"/>Press Release</a></li> 
                    <li style="background: #f1f1f1; font-size:18px;"><a href="partners/"/>Partners</a></li>
                    
                    <li style="background: #f1f1f1; font-size:18px;"><a href="contact.php"/>Contact</li>     
                        <li style="background: #f1f1f1; font-size:18px;"><a href="calendar.php"/>Calendar</li>    
				</ul>
			</div>
		</div>

	<!-- THIS IS THE WRAPPER FOR THE FULL TEMPLAGE -->
	<section class="boxed-wrapper">

		<!-- THE STICKY MENU AT THE TOP  -->
		<header class="header">

			<!-- THE SUB HEADER PAT -->
			 <section class="subheader_wrapper">
					<div class="container">
						<div class="subheader-left one_half nobottommargin">
							<p class="small lh35"><a href="https://www.necs.com/" /><img src="https://www.necs.com/images/256.png" width="75" style="margin-bottom: 0px; margin-top:5px; margin-right: 9px; width: 75px !important;"/></a><strong>Software for Food Distributors</strong>
				   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><a href="emergency/" style="color: #25a114 !important; font-size:13px !important;">ACCESS OUR EMERGENCY 24 HOUR SUPPORT</a></strong>                                
                                          
                     
						  </p>
				  </div>
                        
							<div class="subheader-right one_half lastcolumn">
							
				<div style="float: right; margin-top:2px;">		<font style="font-size:14px; font-weight:bold; font-color: #f00000; margin-right: 35px; ">Toll Free: <strong>800.766.6327</strong> &nbsp;&nbsp;&nbsp;<div class="phone-spacer"></div> Local: <strong>475.221.8200</strong></font> 	<a href="calendar.php" title="View the NECS Calendar"><img src="https://necs.com/images/cal-icon.jpg" height="26" style="height:26px !important;"/></a>			
<a href="https://www.facebook.com/pages/NECS-Inc/186969234681982" target="_blank" title="Visit the NECS, Inc. Facebook Page"><img src="images/content/socialicons/fb.jpg"></a>



&nbsp;<a href="https://www.youtube.com/channel/UC-9mkS7A5XozBMb_OBHS8_g" target="_blank"  title="Visit the NECS, Inc. Youtube Channel"><img src="images/content/socialicons/yt.jpg"></a>




<br>


</div>
						</div>
                        

						<div class="clear"></div>
                        
						<div class="divide20 visible-phone"></div>
					</div>
			</section><!-- END OF SUBHEADER WRAP -->



			<!-- THE HEADER WRAP -->
			<section class="header_wrapper">
				<div class="container" style="height: 95px !important; margin: 0px !important; margin-top: 0px !important;">
					<div class="row" >
							<!-- THE LOGO HOLDER -->
							<div class="span2" style="height: 65px !important;">
								<div class="logoholder" style="margin: 0px !important;">
									<a href="index.php"><img src="images/logo_new.png" alt="" style="max-width: none !important; height: 80px !important; margin-top: 4px !important;"></a>
								</div>
							</div>
							<!-- END OF LOGO HOLDER -->

							<!-- THE NAVIGATION HOLDER -->
							<div class="span10">
								<div id="nav" class="hidden-phone">
												<ul>
													<li><a href="index.php" class="" style="color: #000000 !important;">Home</a></li>


														<li><span class="hassubmenu toplevel"><a href="about.php"  style="color: #000000 !important;">About</a></span>
															<ul>
																<li><a href="about.php">About NECS</a></li>
                                                              
																
																<li><a href="news.php">News</a></li> 
                                                                 <li><a href="press.php">Press Release</a></li>
                                                                <li><a href="testimonials.php">Testimonials</a></li>
                                                               
															</ul>
												  </li>

														<li><span class="hassubmenu toplevel"><a href="entree/"  style="color: #000000 !important;">Products</a></span>
																																									<ul style="width: 778px !important;position:absolute; left:-200px;  min-width: 778px !important;" width="778">

<li style="width: 255px !important; float: left;" class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important;  line-height:41px !important;"><strong>Desktop Applications</strong>
</a></li>


<li style="width: 255px !important; float: left; height: 41px !important;" class="main-menu-li"><a href=""><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div>
 </a></li>


<li style="width: 255px !important; float: left;" class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important;  line-height:41px !important;"><strong>Mobile Applications</strong>
</a></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="entree_food_distribution_software/" title="Food Service Software entrée Food Distribution Software"><div class="inner-menu-item"><strong><font color="#000000">entrée V4:</font></strong></div> <br>
<span>ERP Software for Food Distributors</span></a></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="ap/" title="Food Distribution Software Accounts Payable"><div class="inner-menu-item"><strong><font color="#000000">entrée.AP:</font></strong></div><br>
<span>
Accounts Payable</a></span></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="orderpad/" title="Food Distribution Software Electronic Warehouse Manager"><div class="inner-menu-item"><strong><font color="#000000">Electronic Order Pad:</font></strong></div><br>
<span>
Order Entry & More for Your DSR's </a></span></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="doc/" title="entrée.DOC Document Scanning Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.DOC:</font></strong></div> <br>
<span>
Document Scanning</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="dot/" title="entrée.DOT Food Service Software - DOT Foods Interface"><div class="inner-menu-item"><strong><font color="#000000">entrée.DOT:</font></strong></div> <br>
<span>
The DOT Foods Interface</span></a></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="ewm/" title="Food Distribution Software Electronic Warehouse Manager"><div class="inner-menu-item"><strong><font color="#000000">Electronic Warehouse Manager:</font></strong></div><br>
<span>
Receiving, Picking & more</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="edi/" title="entrée.EDI Electronic Data Interchange"><div class="inner-menu-item"><strong><font color="#000000">entrée.EDI:</font></strong></div> <br>
<span>
EDI Solutions for your Vendors/Customers</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="fs/" title="entrée.FS Food Show Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.FS:</font></strong></div> <br>
<span>
Food Show Software</a></span></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="dsr/" title="Food Distribution Software DSR Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.DSR:</font></strong></div><br>
<span>
Laptop software for your DSRs </a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="gl/" title="entrée.GL General Ledger Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.GL:</font></strong></div> <br>
<span>General Ledger</a></span></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="mw/" title="entrée.MW Multiple Warehouse Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.MW:</font></strong></div> <br>
<span>
Multi Warehouse</a></span></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="pod/" title="Proof of Delivery" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">entrée.POD:</font></strong></div> <br>
<span>
Proof Of Delivery</a></span></li>




<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="ptv/" title="entrée.PTV Pass Through Value"><div class="inner-menu-item"><strong><font color="#000000">entrée.PTV:</font></strong></div> <br>
<span>
USDA "Pass Through Value" for Schools</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="qb/" title="entrée.QB QuickBooks Integrations Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.QB:</font></strong></div> <br>
<span>
QuickBooks Integration</a></span></li>



<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="express/" title="Food Order Entry on Mobile Devices"><div class="inner-menu-item"><strong><font color="#000000">entrée.EXPRESS:</font></strong></div><br>
<span>
Fast Order Entry on Mobile Devices</a></span></li>

<li style="width: 255px !important; float: left; " class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important; line-height:41px !important;"><strong>Website & Online Catalog</strong>
</a></li>

<li style="width: 249px !important; float: left; border-bottom: 1px solid #ededed;  height: 41px !important;"><a href="" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div> 
 </a></li>

<li style="width: 255px !important; float: left;" class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important; line-height:41px !important;"><strong>Internet Applications</strong>
</a></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="website-for-food-distributors/" title="entrée.NET Websites for Food Distributors" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">entrée.NET Website with Catalog:</font></strong></div> <br>
<span>
Quality Websites and Product Catalog</a></span></li>


<li style="width: 249px !important; float: left; border-bottom: 1px solid #ffffff;"><a href="" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div> 
 </a></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="net/" title="entrée.NET Internet Ordering Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.NET:</font></strong></div> <br>
<span>
Website/Internet Order Entry</a></span></li>
<!-- blank box
<li style="width: 249px !important; float: left; border-bottom: 1px solid #ffffff;"><a href=""><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div> 
 </a></li> -->


</ul>							</li>
<li><a href="support/" class=""  style="color: #000000 !important;">Support</a><ul  style="width: 180px !important;">
<li><a href="support/">Customer Login</a></li>
<li><a href="http://manage.necs.com" target="_blank">Pay a Bill</a></li>
<li><a href="emergency/">Emergency 24H Support</a></li>
<li><a href="faq/" target="_blank">FAQ</a></li>
<li><a href="ios13.php">iOS 13</a></li>
																<li><a href="training.php">Training</a></li>
																<li><a href="calendar.php">Event Calendar</a></li>
                                                                  <li><a href="docsearch.php">Document Samples</a></li>
																<li><a href="custom-programming.php">Custom Programming</a></li>
                                                                <li><a href="remotesupport.php">Remote Support</a></li>
															</ul></li>
<li><a href="blog.php" class=""  style="color: #000000 !important;">Blog</a></li>
		<li><a href="partners/" class=""  style="color: #000000 !important;">Partners</a></li>
														<li><a href="contact.php" class=""  style="color: #000000 !important;">Contact</a></li>
                                                        	<li><a href="calendar.php" class=""  style="color: #000000 !important;">Calendar</a></li>
                                                            
                                                            
<li><span class="hassubmenu toplevel"><a href="job-opportunities.php"  style="color: #000000 !important;">Employment</a></span>
															<ul>
																<li><a href="job-opportunities.php">Job Opportunities</a></li>
                                                  
                                                               
															</ul>
												  </li>

 <img src="images/spacer.png" width="150" style="height: 1px !important; width:150px !important;">
												</ul>
                                         
												<div class="clear"></div>

								</div><!-- END OF THE #NAV CONTAINER -->

							
							</div><!-- END OF NAVIGTION HOLDER -->
                            
						</div> <!-- END OF ROW -->
				</div> <!-- END OF CONTAINER -->
			</section> <!-- END OF HEADER WRAPPER  -->

	<div class="resp-navigator"><i class="icon-menu medium gray"></i></div>





	</header>


		<!-- THE CONTENT -->
		<section class="maincontent">

	<!-- THE CONTENT -->
	<section> 
		<section class="container">

			<!-- THE CONTENT HEADER -->

					<!-- THE MAIN INTRO TEXT -->
					<article>
					  <div class="divide20"></div>
						<div class="row">
							<div class="span8">
								<h1 class="bigintro txt-left leftfloat rm20 nobottommargin">Sitemap</h1>
								<p class="leftfloat tm15 bm15 big">NECS.com Sitemap</p>
								<div class="clear"></div>
							</div>
							<div class="span4">
					

							</div>
						</div>
					</article>

					<hr class="nobottommargin">
					<div class="divide2"></div>


				

	


		

		


		  <div class="divide15"></div>
<table border="0" width="100%"><tr>
<td valign="top" align="left" width="59%"><ul type="disc">
  <li>
    <h2><b><a href="index.php" title="NECS Food Distribution Software: ERP, Food Import Software">Home</a><br />
    </b></h2>
  </li>
  <li>
    <h2><b><a href="about.php" title="NECS ERP - Food Distribution Computer, Meat and Seafood Distribution Software">About</a><br />
    </b></h2>
  </li>   <li>
     <h2><b><a href="calendar.php">Event Calendar</a><br />
     </b></h2>
   </li>

  <li>
    <h2><b><a href="support/">Support</a><br />
    </b></h2>
    <h2><b><a href="contact.php">Contact</a></b> </h2>
  </li>

   <li>
    <h2><b><a href="blog.php">Blog</a>
    </b></h2>
    <ul type="disc">
    
           <li><a href="news-article.php?id=344" title="Version 4.4.1.1 of entrée is now available!">Version 4.4.1.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=342" title="Introducing the entrée V4 Dashboards. It is a business intelligence tool which provides snapshots of key performance indicators relevant to your operations. ">New Blog Post: entrée Dashboards</a><br />
      </li>
            <li><a href="news-article.php?id=341" title="Version 4.4.0.2 of entrée is now available!">Version 4.4.0.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=340" title="Version 4.4.0.1 of entrée is now available!">Version 4.4.0.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=338" title="Version 4.3.0.5 of entrée is now available!">Version 4.3.0.5 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=337" title="Version 4.3.0.4 of entrée is now available!">Version 4.3.0.4 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=336" title="Version 4.3.0.3 of entrée is now available!">Version 4.3.0.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=335" title="Version 4.3.0.2 of entrée is now available!">Version 4.3.0.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=334" title="Version 4.3.0.1 of entrée is now available!">Version 4.3.0.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=333" title="Version 4.3.0 of entrée is now available!">Version 4.3.0 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=332" title="Version 4.2.5.4 of entrée is now available!">Version 4.2.5.4 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=331" title="Version 4.2.5.3 of entrée is now available!">Version 4.2.5.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=329" title="Version 4.2.5.2 of entrée is now available!">Version 4.2.5.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=328" title="Version 4.2.5.1 of entrée is now available!">Version 4.2.5.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=327" title="Version 4.2.5 of entrée is now available!">Version 4.2.5 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=326" title="Version 4.2.4.4 of entrée is now available!">Version 4.2.4.4 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=325" title="Version 4.2.4.3 of entrée is now available!">Version 4.2.4.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=324" title="Version 4.2.4.2 of entrée is now available!">Version 4.2.4.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=323" title="Version 4.2.4.1 of entrée is now available!">Version 4.2.4.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=322" title="Version 4.2.4 of entrée is now available!">Version 4.2.4 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=321" title="Version 4.2.3 of entrée is now available!">Version 4.2.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=320" title="Version 4.2.2.6 of entrée is now available!">Version 4.2.2.6 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=319" title="Version 2.5.3a of the entrée Host is now available for download">entrée Host 2.5.3a available</a><br />
      </li>
            <li><a href="news-article.php?id=318" title="Version 4.2.2.5 of entrée is now available!">Version 4.2.2.5 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=317" title="Version 4.2.2.4 of entrée is now available!">Version 4.2.2.4 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=316" title="Version 4.2.2.3 of entrée is now available!">Version 4.2.2.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=315" title="Version 4.2.2.2 of entrée is now available!">Version 4.2.2.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=314" title="Version 4.2.2.1 of entrée is now available!">Version 4.2.2.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=313" title="Version 4.2.2 of entrée is now available!">Version 4.2.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=312" title="Version 4.2.1.3 of entrée is now available!">Version 4.2.1.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=311" title="Version 4.2.1.2 of entrée is now available!">Version 4.2.1.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=309" title="Read company founder Chris Anatra's latest Blog article for our official Roadmap of projects for 2019">NECS Roadmap 2019</a><br />
      </li>
            <li><a href="news-article.php?id=310" title="Please note that our office will be closed 12/24/18-12/25/18 for the Christmas holiday and 12/31/18-1/1/19 for the New Year holiday.">NECS Holiday Closing Schedule</a><br />
      </li>
            <li><a href="news-article.php?id=308" title="Version 4.2.1.1 of entrée is now available!">Version 4.2.1.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=307" title="Version 4.2.1 of entrée is now available!">Version 4.2.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=306" title="Version 4.2.0.4 of entrée is now available!">Version 4.2.0.4 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=305" title="Version 4.2.0.3 of entrée is now available!">Version 4.2.0.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=304" title="Version 4.2.0.2 of entrée is now available!">Version 4.2.0.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=303" title="Version 4.2.0.1 of entrée is now available!">Version 4.2.0.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=301" title="Version 1.1.23 of entrée.DSR is now available for download.">Version 1.1.23 of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=302" title="Version 2.5.3 of the entrée Host is now available for download">entrée Host 2.5.3 available</a><br />
      </li>
            <li><a href="news-article.php?id=300" title="Version 4.2.0 of entrée is now available!">Version 4.2.0 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=299" title="Industry Leader in ERP Software for Food Distributors Now Gives Customers  Go-To Tool for Convenient and Efficient Mobile Food Ordering ">NECS, Inc. Launches entrée.EXPRESS Mobile Ordering App</a><br />
      </li>
            <li><a href="news-article.php?id=298" title="Version 4.1.3 of entrée is now available for download.">Version 4.1.3.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=297" title="Version 4.1.3 of entrée is now available for download.">Version 4.1.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=296" title="Version 4.1.2 of entrée is now available for download.">Version 4.1.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=295" title="Version 4.1.1.3 of entrée.QB is now available for download.">Version 4.1.1.3 of entrée.QB is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=294" title="Version 4.1.1.4 of entrée is now available for download.">Version 4.1.1.4 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=293" title="Version 4.1.1.3 of entrée is now available for download.">Version 4.1.1.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=292" title="Version 3.6.42 of entrée is now available for download">Version 3.6.42 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=291" title="Version 4.1.1.2 of entrée is now available for download.">Version 4.1.1.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=290" title="Version 4.1.1.1 of entrée is now available for download.">Version 4.1.1.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=289" title="NECS to attend the DOT Foods Innovation show on May 31st, 2018">NECS to attend the DOT Foods Innovation show on May 31st, 2018</a><br />
      </li>
            <li><a href="news-article.php?id=288" title="NECS has put together a variety of training courses which will bring your staff up to speed and give them a tremendous comfort level when using entrée.">entree V4 Training on May 16th, 2018!</a><br />
      </li>
            <li><a href="news-article.php?id=287" title="NECS has put together a variety of training courses which will bring your staff up to speed and give them a tremendous comfort level when using entrée.">entree V4 Training on March 14th, 2018!</a><br />
      </li>
            <li><a href="news-article.php?id=286" title="Happy Holidays from NECS, Inc. Please note our offices will be closed on the following days: 12/25/17, 12/26/17 and 1/1/18. If you have an emergency when our office is closed, please visit: https://necs.com/emergency/ Thank you and have a great holiday season.">NECS Holiday Closings</a><br />
      </li>
            <li><a href="news-article.php?id=285" title="Version 4.1.0.3 of entrée is now available for download.">Version 4.1.0.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=284" title="Version 4.1.0.2 of entrée is now available for download.">Version 4.1.0.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=283" title="Version 1.1.22 of entrée.DSR is now available for download.">Version 1.1.22 of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=282" title="Version 2.5.2 of the entrée Host is now available for download">entrée Host 2.5.2 available</a><br />
      </li>
            <li><a href="news-article.php?id=281" title="Version 4.1.0.1 of entrée is now available for download.">Version 4.1.0.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=280" title="Version 4.0.43.1 of entrée is now available for download.">Version 4.0.43.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=279" title="Version 4.0.42.2 of entrée is now available for download.">Version 4.0.42.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=278" title="Version 2.5.1c of the entrée Host is now available for download">entrée Host 2.5.1c available</a><br />
      </li>
            <li><a href="news-article.php?id=277" title="Version 4.0.42.1 of entrée is now available for download.">Version 4.0.42.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=276" title="Version 2.5.0.0 of entrée.QB is now available for download.">Version 2.5.0.0 of entrée.QB is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=275" title="Version 1.6.0.0 of entrée.QB is now available for download.">Version 1.6.0.0 of entrée.QB is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=274" title="Version 4.0.42 of entrée is now available for download.">Version 4.0.42 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=273" title="Version 4.0.41.3 of entrée is now available for download.">Version 4.0.41.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=272" title="Version 4.0.41.2 of entrée is now available for download.">Version 4.0.41.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=271" title="Version 4.0.41.1 of entrée is now available for download.">Version 4.0.41.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=270" title="Version 3.6.41 of entrée is now available for download">Version 3.6.41 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=269" title="NECS Software Engineer, Tony Vlahos, Named "Rock Star of the Supply Chain" by Food Logistics Magazine!">NECS Software Engineer, Tony Vlahos, Named "Rock Star of the Supply Chain" by Food Logistics Magazine!</a><br />
      </li>
            <li><a href="news-article.php?id=268" title="Version 4.0.41 of entrée is now available for download.">Version 4.0.41 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=267" title=""></a><br />
      </li>
            <li><a href="news-article.php?id=265" title="NECS, Inc. President, Chris Anatra, has posted a new Blog article regarding our Company Roadmap for 2017-2018">New Blog article- NECS Company Roadmap 2017-2018</a><br />
      </li>
            <li><a href="news-article.php?id=266" title="NECS will be at Booth 205 at the Golbon Spring Member Conference!">NECS will be at Booth 205 at the Golbon Spring Member Conference!</a><br />
      </li>
            <li><a href="news-article.php?id=264" title="Version 3.6.40 of entrée is now available for download">Version 3.6.40 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=263" title="NECS will be at booth 402 at the Bellissimo Show!">NECS will be at booth 402 at the Bellissimo Show!</a><br />
      </li>
            <li><a href="news-article.php?id=262" title="Version 4.0.40.2 of entrée is now available for download.">Version 4.0.40.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=261" title="Version 4.0.40.1 of entrée is now available for download.">Version 4.0.40.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=260" title="Version 4.0.40 of entrée is now available for download.">Version 4.0.40 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=259" title="NECS Announces Training Dates for 2017">NECS Announces Training Dates for 2017</a><br />
      </li>
            <li><a href="news-article.php?id=257" title="NECS Holiday Schedule">NECS Holiday Schedule</a><br />
      </li>
            <li><a href="news-article.php?id=256" title="Version 4.0.39.4 of entrée is now available for download.">Version 4.0.39.4 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=255" title="Version 3.6.39 of entrée is now available for download">Version 3.6.39 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=254" title="Version 4.0.39.3 of entrée is now available for download.">Version 4.0.39.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=253" title="Version 4.0.39.2 of entrée is now available for download.">Version 4.0.39.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=252" title="Version 4.0.39.1 of entrée is now available for download.">Version 4.0.39.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=250" title="Version 4.0.38.3 of entrée is now available for download.">Version 4.0.38.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=249" title="Insight Success Magazine Recognizes NECS President, Chris Anatra among 50 most creative CEO's to watch. ">Insight Success Magazine Recognizes NECS President, Chris Anatra among 50 most creative CEO's to watch. </a><br />
      </li>
            <li><a href="news-article.php?id=11" title="Visit us at booth #421 at the Golbon "Fall Member Conference", in Providence, RI, October 26-29,2016">NECS at the Golbon Fall Member Conference Oct. 26th-29th in Providence, RI</a><br />
      </li>
            <li><a href="news-article.php?id=203" title="NECS will be at booth #9 at the upcoming Legacy Foodservice Alliance Fall Marketplace Meeting in Atlanta, GA on September 25th-27th. ">NECS to be at the Legacy Foodservice Alliance Fall Marketplace in Atlanta, September 25th-27th, 2016</a><br />
      </li>
            <li><a href="news-article.php?id=247" title="On October 25th, 2016 at our new offices in Branford, CT, NECS will be holding our first Partner Showcase Event.">NECS Partners Showcase Event - October 25th, 2016 - Branford, CT</a><br />
      </li>
            <li><a href="news-article.php?id=246" title="Version 4.0.38.1 of entrée is now available for download.">Version 4.0.38.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=245" title="Version 4.0.38 of entrée is now available for download.">Version 4.0.38 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=220" title="NECS announces our latest entrée training dates, September 21-23, 2016 held at our our new offices in Branford, CT.">NECS announces entrée V4 3-day training course, September 21-23, 2016</a><br />
      </li>
            <li><a href="news-article.php?id=244" title="New Blog by NECS President, Chris Anatra, About Our Anoto Digital Pen Promotion!">New Blog by NECS President, Chris Anatra, About Our Anoto Digital Pen Promotion!</a><br />
      </li>
            <li><a href="news-article.php?id=243" title="Version 3.6.38a of entrée is now available for download">Version 3.6.38a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=242" title="Version 3.6.38 of entrée is now available for download">Version 3.6.38 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=241" title="Version 4.0.37.2 of entrée is now available for download.">Version 4.0.37.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=240" title="Version 4.0.37.1 of entrée is now available for download.">Version 4.0.37.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=239" title="New Blog by NECS President, Chris Anatra, Regarding GS1 Connect 2016!">New Blog by NECS President, Chris Anatra, Regarding GS1 Connect 2016!</a><br />
      </li>
            <li><a href="news-article.php?id=238" title="Version 4.0.37 of entrée is now available for download.">Version 4.0.37 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=237" title="NECS, Inc. Announces Technology Partnership and Integration with VistaTrac!">NECS, Inc. Announces Technology Partnership and Integration with VistaTrac!</a><br />
      </li>
            <li><a href="news-article.php?id=236" title="New Blog by NECS President, Chris Anatra, Regarding Dot Foods "Innovations 2016"">New Blog by NECS President, Chris Anatra, Regarding Dot Foods "Innovations 2016"</a><br />
      </li>
            <li><a href="news-article.php?id=235" title="CIO Applications Magazine Recognizes NECS among Top 25 ERP Solutions Transforming Business in 2016">CIO Applications Magazine Recognizes NECS among Top 25 ERP Solutions Transforming Business in 2016</a><br />
      </li>
            <li><a href="news-article.php?id=234" title="Version 4.0.36 of entrée is now available for download.">Version 4.0.36 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=73" title="The next scheduled 3-day training class for entree will take place Wednesday June 22nd - 24th, 2016, at our new offices in Branford, CT">NECS entrée Training Class Scheduled for June 22 - 24, 2016</a><br />
      </li>
            <li><a href="news-article.php?id=233" title="Company president Chris Anatra shares his views from the MODEX Show in Atlanta.">New Blog by NECS President, Chris Anatra, regarding MODEX Show in Atlanta, where the latest in warehousing technology was on display</a><br />
      </li>
            <li><a href="news-article.php?id=232" title="Version 4.0.35 of entrée is now available for download.">Version 4.0.35 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=231" title="Food Logistics, the only publication dedicated exclusively to the global food and beverage supply chain, announces that President of NECS,Inc. Chris Anatra was awarded the second annual “Food Logistics Champions: Rock Stars of the Supply Chain,” award.">NECS President, Chris Anatra, recognized as a recipient of the "2016 Food Logistics Champions: Rock Stars of the Supply Chain”</a><br />
      </li>
            <li><a href="news-article.php?id=230" title="Version 3.6.37 of entrée is now available for download">Version 3.6.37 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=229" title="Version 4.0.34.1 of entrée is now available for download.">Version 4.0.34.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=228" title="Version 4.0.34 of entrée is now available for download.">Version 4.0.34 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=227" title="NECS will be at the Bellissimo Buying Conference,Fort Lauderdale, FL, April 20-22, 2016">NECS will be at the Bellissimo Buying Conference, April 20-22, 2016, Fort Lauderdale, FL</a><br />
      </li>
            <li><a href="news-article.php?id=226" title="NECS will be at the Golbon "Mid-Year Spring Member Conference & Buying Show", in Las Vegas, NV, April 12-15, 2016">NECS to be at the Golbon Mid-Year Spring Buying Show, April 12-15, 2016, Las Vegas, NV</a><br />
      </li>
            <li><a href="news-article.php?id=225" title="Version 4.0.33.2 of entrée is now available for download.">Version 4.0.33.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=224" title="Version 4.0.33.1 of entrée is now available for download.">Version 4.0.33.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=223" title="Version 4.0.33 of entrée is now available for download.">Version 4.0.33 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=221" title="Visit NECS at The United Group Conference", Las Vegas, Nevada, March 28-31, 2016 at The Wynn Hotel & Resort.">NECS to be at The United Group Conference in Las Vegas, March 28-31, 2016</a><br />
      </li>
            <li><a href="news-article.php?id=219" title="NECS announces our first 3-day training course of the year, set for March 2-4, 2016 at our new offices in Branford, CT">NECS announces our first entrée V4 3-day training course of 2016: March 2nd - 4th</a><br />
      </li>
            <li><a href="news-article.php?id=218" title="Version 4.0.32 of entrée is now available for download.">Version 4.0.32 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=216" title="NECS announces a reduced staff on 12/18/15 due to our company holiday party and closed Christmas Eve / Day, half day New Years Eve and closed New Years Day.">NECS to Have Reduced Staff on Friday, December 18th and Holiday Closures</a><br />
      </li>
            <li><a href="news-article.php?id=214" title="A new Blog article has been posted by company president Chris Anatra regarding new Warehouse Slotting features, an update to our Anoto Pen project and more about what's going on at NECS for 2016.">New Blog Posting about Warehouse Slotting, Update on the Anoto Pen and What's Happening at NECS for 2016</a><br />
      </li>
            <li><a href="news-article.php?id=213" title="Visit us at Booth #388 at the Seafood Expo - North America on March 6-8th, 2016 at the Boston Convention and Exhibition Center.">NECS to be at the Seafood Expo North America - formerly the Boston Seafood Show, March 6-8, 2016, Boston, MA - click here for your FREE VIP Pass</a><br />
      </li>
            <li><a href="news-article.php?id=211" title="Version 4.0.31 of entrée is now available for download.">Version 4.0.31 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=210" title="Special upgrade offer for upgrading to entrée V4, expires 12/31/15">Special upgrade offer for entrée V4, expires 12/31/15</a><br />
      </li>
            <li><a href="news-article.php?id=209" title="Version 3.6.36a of entrée is now available for download">Version 3.6.36a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=206" title="Version 2.4.0.0 of entrée.QB is now available for download.">Version 2.4.0.0 of entrée.QB is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=208" title="Version 3.6.36 of entrée is now available for download">Version 3.6.36 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=207" title="Version 4.0.2 of entrée.UPC is now available">Version 4.0.2 of entrée.UPC is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=205" title="Version 4.0.30 of entrée is now available for download.">Version 4.0.30 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=204" title="Version 4.0.29 of entrée is now available for download.">Version 4.0.29 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=201" title="Version 4.0.28 of entrée is now available for download.">Version 4.0.28 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=200" title="Version 4.0.27 of entrée is now available for download.">Version 4.0.27 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=199" title="NECS has scheduled our next 3-day training course for entrée V4 to take place Wednesday, Sept 23th - Friday, Sept 25th, 2015.">NECS V4 Training Scheduled for Sept 23-25, 2015</a><br />
      </li>
            <li><a href="news-article.php?id=198" title="Version 3.6.35 of entrée is now available for download">Version 3.6.35 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=197" title="Interfacing entrée V4 with the Anoto Digital Pen to help automate your drivers.">New Blog Posting - Interfacing with the Anoto Digital Pen</a><br />
      </li>
            <li><a href="news-article.php?id=196" title="NECS will be closed on Friday, July 3rd in observance of the Independence Day holiday">NECS holiday closing</a><br />
      </li>
            <li><a href="news-article.php?id=195" title="Version 4.0.26 of entrée is now available for download.">Version 4.0.26 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=194" title="Version 4.0.25 of entrée is now available for download.">Version 4.0.25 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=193" title="Version 4.0.24 of entrée is now available for download.">Version 4.0.24 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=192" title="Version 4.0.23 of entrée is now available for download.">Version 4.0.23 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=191" title="Version 4.0.22 of entrée is now available for download.">Version 4.0.22 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=190" title="Version 4.0.20 of entrée is now available for download.">Version 4.0.20 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=189" title="Version 3.6.34 of entrée is now available for download">Version 3.6.34 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=188" title="NECS will be at the Dot Food Show, Innovations 2015, Friday, May 8th, 2015 in St. Louis, booth #177.">NECS will be at the Dot Food Show - Friday, May 8th, 2015, St. Louis</a><br />
      </li>
            <li><a href="news-article.php?id=187" title="Version 4.0.19 of entrée is now available for download.">Version 4.0.19 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=186" title="Version 1.5.0.0 of entrée.QB is now available for download.">Version 1.5.0.0 of entrée.QB is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=185" title="Version 3.6.33 of entrée is now available for download">Version 3.6.33 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=184" title="The next scheduled 3-day training class for entree will take place 3/18 - 3/20, 2015, at our offices in Madison, CT">NECS entree Training Class scheduled for March 18th - March 20th, 2015</a><br />
      </li>
            <li><a href="news-article.php?id=183" title="Version 1.1.21d of entrée.DSR is now available for download.">Version 1.1.21d of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=182" title="Version 4.0.18 of entrée is now available for download.">Version 4.0.18 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=181" title="Due to the historic blizzard due to hit Connecticut this afternoon (Monday, 1/26/15) and Connecticut closing its roads, we are closing our office at 3PM and plan to be closed all day Tuesday">NECS Closing early Monday, Jan 26 & all day Tuesday, Jan 27 for Snow Storm</a><br />
      </li>
            <li><a href="news-article.php?id=180" title="Version 3.6.32 of entrée is now available for download">Version 3.6.32 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=179" title="Version 1.4.0.0 of entrée.QB is now available for download.">Version 1.4.0.0 of entrée.QB is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=178" title="NECS will be closed for the Christmas holiday on Thursday, December 25th and Friday, December 26th. We will be open until noon on New Years Eve, December 31st and closed on January 1st.">NECS Holiday Hours - Closed 12/25 & 12/26 - half day 12/31 - Closed 01/01</a><br />
      </li>
            <li><a href="news-article.php?id=177" title="Version 4.0.17 of entrée is now available for download.">Version 4.0.17 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=176" title="Version 2.5.1b of the entrée Host is now available for download">entrée Host 2.5.1b available</a><br />
      </li>
            <li><a href="news-article.php?id=175" title="Version 4.0.16 of entrée is now available for download.">Version 4.0.16 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=174" title="Version 2.5.1a of the entrée Host is now available for download">entrée Host 2.5.1a available</a><br />
      </li>
            <li><a href="news-article.php?id=173" title="Version 1.1.21c of entrée.DSR is now available for download.">Version 1.1.21c of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=172" title="Version 4.0.15 of entrée is now available for download.">Version 4.0.15 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=171" title="Version 3.6.31 of entrée is now available for download">Version 3.6.31 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=170" title="Version 4.0.14 of entrée is now available for download.">Version 4.0.14 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=169" title="Version 2.5.1 of the entrée Host is now available for download">entrée Host 2.5.1 available</a><br />
      </li>
            <li><a href="news-article.php?id=168" title="Version 4.0.13 of entrée is now available for download.">Version 4.0.13 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=167" title="Version 3.6.30 of entrée is now available for download">Version 3.6.30 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=166" title="Version 4.0.12 of entrée is now available for download.">Version 4.0.12 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=164" title="Version 4.0.11 of entrée is now available for download.">Version 4.0.11 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=163" title="Version 4.0.10 of entrée is now available for download.">Version 4.0.10 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=162" title="Version 3.6.28 of entrée is now available for download">Version 3.6.28 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=161" title="Version 4.0.9 of entrée is now available for download.">Version 4.0.9 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=160" title="Version 4.0.8 of entrée is now available for download.">Version 4.0.8 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=159" title="Our next 3-day training course for entrée V4 has been scheduled for Wednesday, October 22nd through Friday, October 24th, 2014 at our office in Madison, CT. Note that the first day covers new V4 features.">entrée V4 training scheduled for October 22-24, 2014</a><br />
      </li>
            <li><a href="news-article.php?id=158" title="Visit NECS at the Golbon "Philadelphia Fall Conference", in Philadelphia, PA, October 15-16, 2014 at the downtown Marriott.">NECS to be at the Golbon Fall Conference in Philadelphia, October 15-16, 2014</a><br />
      </li>
            <li><a href="news-article.php?id=157" title="Version 4.0.7 of entrée is now available for download.">Version 4.0.7 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=156" title="Version 3.6.27a of entrée is now available for download">Version 3.6.27a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=155" title="Version 2.5.0a of the entrée Host is now available for download">entrée Host 2.5.0a available</a><br />
      </li>
            <li><a href="news-article.php?id=154" title="Version 3.6.27 of entrée is now available for download">Version 3.6.27 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=153" title="Version 4.0.6 of entrée is now available for download.">Version 4.0.6 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=152" title="Version 4.0.5 of entrée is now available for download.">Version 4.0.5 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=151" title="Version 3.6.26a of entrée is now available for download">Version 3.6.26a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=150" title="Version 3.6.26 of entrée is now available for download">Version 3.6.26 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=149" title="Version 4.0.4 of entrée is now available for download.">Version 4.0.4 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=148" title="Version 4.0.3a of entrée is now available for download.">Version 4.0.3a of entrée is now available! Please read this article if you are planning to install the "4.0.3a" update.</a><br />
      </li>
            <li><a href="news-article.php?id=145" title="Version 4.0.3 of entrée is now available for download">Version 4.0.3 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=144" title="I would like to announce that for the second year, NECS will be at the Dot Foods Annual Trade Show called Innovations 2014.
">NECS will be at the Dot Foods Show - Friday, May 9th - St. Louis</a><br />
      </li>
            <li><a href="news-article.php?id=143" title="Version 4.0.2 of entrée is now available for download">Version 4.0.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=142" title="Version 3.6.25 of entrée is now available for download">Version 3.6.25 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=141" title="Version 4.0.1 of entrée is now available for download">Version 4.0.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=140" title="Version 2.5.0 of the entrée Host is now available for download">entrée Host 2.5.0 available</a><br />
      </li>
            <li><a href="news-article.php?id=139" title="Version 1.1.21b of entrée.DSR is now available for download.">Version 1.1.21b of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=138" title="Version 4.0.0 of entrée is now available for download">Version 4.0.0 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=137" title="NECS has scheduled our next 3-day training course for entrée V4 to take place Wednesday, April 9th - Friday, April 11th, 2014.">NECS V4 Training Scheduled for April 9-11, 2014</a><br />
      </li>
            <li><a href="news-article.php?id=136" title="NECS will be the Dot Food Show - Innovations 2014 - May 9, 2014 in St. Louis, MO, booth #172.">NECS will be at the Dot Food Show - Friday, May 9th - St. Louis</a><br />
      </li>
            <li><a href="news-article.php?id=135" title="Our next 3-day training course for entrée V4 has been scheduled for March 5-7, 2014 at our offices in Madison, CT.">NECS V4 Training Scheduled for March 5-7, 2014</a><br />
      </li>
            <li><a href="news-article.php?id=134" title="Version 3.6.24 of entrée is now available for download">Version 3.6.24 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=133" title="NECS wished our customers a safe and enjoyable holiday!  We will be closed December 24th & 25th. We will be open from 8:30AM to 1:00PM on December 31st, and closed January 1st.">NECS Holiday Hours</a><br />
      </li>
            <li><a href="news-article.php?id=132" title="Version 3.6.23b of entrée is now available for download">Version 3.6.23b of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=131" title="Our next 4-day training course for entrée V4 has been scheduled for Wednesday, January 15th through Friday, January 17th, 2014 at our office in Madison, CT.  Note that the first day covers new V4 features.">entrée V4 training scheduled for January 15-17, 2014</a><br />
      </li>
            <li><a href="news-article.php?id=130" title="Version 3.6.23a of entrée is now available for download">Version 3.6.23a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=129" title="Version 3.6.23 of entrée is now available for download">Version 3.6.23 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=128" title="Version 3.6.22 of entrée is now available for download">Version 3.6.22 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=127" title="NECS President, Chris Anatra, explains our new software maintenance rates, new inventory features and the new Daily Summary Dashboards">New Blog Posting - New Software Maintenance rates / New Inventory Features / Daily Summary</a><br />
      </li>
            <li><a href="news-article.php?id=126" title="NECS President, Chris Anatra, shares his third Video Blog which is a preview of entrée's new Cycle Count feature.">New Blog Posting - Cycle Counts</a><br />
      </li>
            <li><a href="news-article.php?id=125" title="NECS President, Chris Anatra, shares his second Video Blog which is a preview of the Dashboard features of V4.">New Blog Posting - Dashboards</a><br />
      </li>
            <li><a href="news-article.php?id=124" title="NECS President, Chris Anatra, provides a release status on V4 and includes his first Video Blog covering the new Search Screens.
<div style="display: none;"><a href="http://www.goldtravestiler.com" title="istanbul travesti">istanbul travesti</a></div>">New Blog Posting - Enhanced Search Screens</a><br />
      </li>
            <li><a href="news-article.php?id=123" title="Visit NECS at the Golbon Fall Conference, October 3-4, 2013 at the Hilton Bonnet Creek Inn, Orlando, FL">Visit NECS at the Golbon Fall Conference, October 3-4, 2013</a><br />
      </li>
            <li><a href="news-article.php?id=122" title="Version 3.6.21a of entrée is now available for download">Version 3.6.21a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=121" title="Version 3.6.21 of entrée is now available for download">Version 3.6.21 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=120" title="Version 3.6.20c of entrée is now available for download">Version 3.6.20c of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=118" title="NECS will be at the Select Marketing conference at the Tradewinds Resort, St. Pete Beach, FL on August 1-2, 2013">NECS to be at the Select Marketing conference</a><br />
      </li>
            <li><a href="news-article.php?id=117" title="Version 3.6.20a of entrée is now available for download">Version 3.6.20a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=116" title="Version 3.6.20 of entrée is now available for download">Version 3.6.20 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=115" title="Version 3.6.19 of entrée is now available for download">Version 3.6.19 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=114" title="As we get closer to the launch of our new entrée V4 SQL software, this Blog posting contains important information to help you develop your company's implementation plan.">New Blog Posting</a><br />
      </li>
            <li><a href="news-article.php?id=113" title="The Evolution of the NECS menu structure, including a sneak peak at the new entree V4 SQL "Ribbon Menu".">New Blog Posting</a><br />
      </li>
            <li><a href="news-article.php?id=112" title="Version 3.6.18a of entrée is now available for download">Version 3.6.18a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=111" title="Version 3.6.18 of entrée is now available for download">Version 3.6.18 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=109" title="NECS will have a booth at the Dot Foods Show - June 6-8, 2013 in St. Louis, MO.  The show is titled "Innovations 2013".">NECS to be at the Dot Foods Show - June 6-8, 2013, St. Louis, MO</a><br />
      </li>
            <li><a href="news-article.php?id=108" title="A new Blog posting regarding Credit Memos with the ELECTRONIC ORDER PAD, new entree.NET web site templates and more.">New Blog Posting</a><br />
      </li>
            <li><a href="news-article.php?id=107" title="Version 3.6.17 of entrée is now available for download">Version 3.6.17 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=106" title="A new Blog posting has been made by Chris Anatra, President of NECS, Inc., regarding the status of entree version 4 SQL and five things you need to know before installing.">New Blog Posting - Status of version 4 SQL and five things you need to know before installation</a><br />
      </li>
            <li><a href="news-article.php?id=105" title="Visit NECS at the Golbon Mid-Year Meeting & Buying Show, May 1-4, 2013, Indianapolis, IN">Visit NECS at the Golbon Mid-Year Meeting & Buying Show, May 1-4, Indianapolis, IN</a><br />
      </li>
            <li><a href="news-article.php?id=104" title="NECS will be at booth #290 at the Boston Seafood Show and would like to offer you FREE VIP admission.">NECS to be at the Boston Seafood Show, March 10-12, 2013</a><br />
      </li>
            <li><a href="news-article.php?id=103" title="A new Blog posting has been made by Chris Anatra, President of NECS, Inc., regarding the new ELECTRONIC WAREHOUSE MANAGER app for Android.">New Blog Posting - ELECTRONIC WAREHOUSE MANAGER</a><br />
      </li>
            <li><a href="news-article.php?id=102" title="Version 3.6.16 of entrée is now available for download">Version 3.6.16 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=101" title="Version 3.6.15 of entrée is now available for download">Version 3.6.15 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=100" title="Our ELECTRONIC ORDER PAD app for Android is now in the Google Play Store for your immediate download.  Currently supporting the 7" Google Nexus tablet.">ELECTRONIC ORDER PAD now in the Google Play Store</a><br />
      </li>
            <li><a href="news-article.php?id=99" title="On Thursday evening, November 1st, power, phones and Internet access was restored to our office.">NECS office services restored after Hurricane Sandy</a><br />
      </li>
            <li><a href="news-article.php?id=98" title="NECS employees are currently working from there homes to respond to customer technical support assistance and new customer inquiries. Please click here to see email addresses to reach us.">NECS office remains closed after Hurricane Sandy</a><br />
      </li>
            <li><a href="news-article.php?id=97" title="The town of Madison, CT has issued a mandatory evacuation for the area where NECS, Inc. offices are located, beginning at 8PM, Sunday, October 28th.  Expect difficulty in reaching our office until the storm passes and services are restored.">Hurricane Sandy impacts NECS</a><br />
      </li>
            <li><a href="news-article.php?id=96" title="Version 3.6.14 of entrée is now available for download">Version 3.6.14 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=95" title="Version 3.6.13a of entrée is now available for download">Version 3.6.13a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=93" title="Version 1.1.21a of entrée.DSR is now available for download.">Version 1.1.21a of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=92" title="Version 3.6.12a of entrée is now available for download">Version 3.6.12a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=91" title="Our latest Blog posting covers some new features added to entree.NET and the ELECTRONIC ORDER PAD.">New Blog Posting - entree.NET and ELECTRONIC ORDER PAD features</a><br />
      </li>
            <li><a href="news-article.php?id=90" title="Version 3.6.12 of entrée is now available for download">Version 3.6.12 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=89" title="Version 3.6.11a of entrée is now available for download">Version 3.6.11a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=88" title="Version 3.6.11 of entrée is now available for download">Version 3.6.11 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=86" title="Version 3.6.10 of entrée is now available for download">Version 3.6.10 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=87" title="Version 1.1.21 of entrée.DSR is now available for download.">Version 1.1.21 of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=85" title="Version 1.1.20b of entrée.DSR is now available for download.">Version 1.1.20b of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=83" title="Version 3.6.9a of entrée is now available for download">Version 3.6.9a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=84" title="A breakdown of the features being added to entree Version 4, project: Red Velvet Cupcake.">New Blog Posting - Version 4 Ingredients/Features List</a><br />
      </li>
            <li><a href="news-article.php?id=82" title="Version 1.1.20a of entrée.DSR is now available for download.">Version 1.1.20a of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=81" title="Our new Language Translator allows your customers placing their orders online, via entree.NET, to read your item descriptions, class names and item notes in the language of their choice.">NECS announces the Language Translator</a><br />
      </li>
            <li><a href="news-article.php?id=80" title="Version 3.6.9 of entrée is now available for download">Version 3.6.9 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=79" title="Version 3.6.8b of entrée is now available for download">Version 3.6.8b of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=78" title="Details are revealed about the next version of entree, code name: Red Velvet Cupcake.">New Blog Posting - Project RED VELVET CUPCAKE</a><br />
      </li>
            <li><a href="news-article.php?id=77" title="Version 1.1.20 of entrée.DSR is now available for download.">Version 1.1.20 of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=76" title="Version 3.6.8a of entrée is now available for download">Version 3.6.8a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=74" title="Because the May training class is full, another 3-Day class has been scheduled for June 27th-29th 2012, at our offices in Madison, CT.">NECS entree Training Class scheduled for June 27-29, 2012</a><br />
      </li>
            <li><a href="news-article.php?id=72" title="Version 3.6.7b of entrée is now available for download">Version 3.6.7b of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=71" title="Visit NECS at the Golbon Mid-Year Meeting & Buying Show in Pittsburgh, PA on April 20th, 2012.">NECS at the Golbon Mid-Year Meeting & Buying Show, April 20th, 2012</a><br />
      </li>
            <li><a href="news-article.php?id=70" title="Version 3.6.7a of entrée is now available for download.<br>
entrée.UPC customers please read the detailed description of this update.">Version 3.6.7a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=69" title="Version 2.2.10 of entrée.UPC (bar code scanning) is now available for download<br>
Please read the detailed description of this update.">Version 2.2.10 of entrée.UPC is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=68" title="Version 1.1.19 of entrée.DSR is now available for download.">Version 1.1.19 of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=67" title="Version 3.6.7 of entrée is now available for download.<br>
entrée.UPC customers please read the detailed description of this update.">Version 3.6.7 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=66" title="This latest Blog posting is a photo journal showing the ELECTRONIC LOADING SHEET in action.  Pictures were taken on January 10th, 2012 at George's Seafood in Norfolk, VA.">New Blog Posting - Photos of the ELS in action</a><br />
      </li>
            <li><a href="news-article.php?id=65" title="In observance of the Christmas holiday, NECS offices will be closed on Friday, December 23rd and Monday, December 26th.
In observance of the New Year holiday, NECS offices will be closed on Monday, January 2nd.">NECS Holiday Close Dates</a><br />
      </li>
            <li><a href="news-article.php?id=64" title="Version 3.6.6b of entrée is now available for download.

This update is only required for distributors with entrée.DOT">Version 3.6.6b of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=63" title="Version 3.6.6a of entrée is now available for download.">Version 3.6.6a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=62" title="Version 3.6.6 of entrée is now available for download.">Version 3.6.6 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=61" title="Version 1.1.18a of entrée.DSR is now available for download.">Version 1.1.18a of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=60" title="Version 1.1.18 of entrée.DSR is now available for download.">Version 1.1.18 of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=59" title="Version 3.6.5 of entrée is now available for download.">Version 3.6.5 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=58" title="As a way to provide you with the latest projects we are working on, and to get your feedback, we've created a new Blog section to our Web site. The first posting is regarding the upcoming ELECTRONIC LOADING SHEET.">First Blog posting - the ELECTRONIC LOADING SHEET</a><br />
      </li>
            <li><a href="news-article.php?id=57" title="Version 3.6.4a of entrée is now available for download.">Version 3.6.4a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=56" title="Version 3.6.4 of entrée is now available for download.">Version 3.6.4 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=55" title="Version 1.1.0.1 of entrée.QB is now available for download.">Version 1.1.0.1 of entrée.QB is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=54" title="Version 3.6.3b of entrée is now available for download.">Version 3.6.3b of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=53" title="Version 3.6.3a of entrée is now available for download.">Version 3.6.3a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=52" title="Visit NECS at the Golbon Fall Partners Conference and Annual Awards in Boise, ID on October 12-15th, 2011">NECS at the Golbon Fall Partners Conference, October 12-15th, 2011</a><br />
      </li>
            <li><a href="news-article.php?id=51" title="After a week without power and Internet access because of Hurricane Irene, all services finally restored.">Power and Internet restored to NECS offices</a><br />
      </li>
            <li><a href="news-article.php?id=50" title="NECS power and Internet outage">Hurricane Irene knocks out NECS power and Internet access</a><br />
      </li>
            <li><a href="news-article.php?id=49" title="Version 3.6.2 of entrée is now available for download.">Version 3.6.2 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=48" title="NECS, Inc. announced its latest software application for the Apple iPad: the ELECTRONIC ORDER PAD, which provides powerful order entry and sales prospecting tools for food distribution sales representatives.">Press Release: NECS, Inc. Announces ELECTRONIC ORDER PAD</a><br />
      </li>
            <li><a href="news-article.php?id=47" title="Version 3.6.1 of entrée is now available for download.">Version 3.6.1 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=46" title="Visit NECS at Select Marketing's Buying Group Meeting, July 29th, 2011, at the Marriott Marco Island Gulf Resort & Spa, Marco Island, FL">Visit NECS at Select Marketing's Buying Group Meeting, July 29th</a><br />
      </li>
            <li><a href="news-article.php?id=45" title="Version 1.1.17 of entrée.DSR is now available for download.">Version 1.1.17 of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=44" title="Version 3.6.0 of entrée is now available for download.">Version 3.6.0 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=43" title="NECS has compiled a list of the many questions customers have been asking about the new ELECTRONIC ORDER PAD. Click here to review all the questions and answers.">ELECTRONIC ORDER PAD Frequently Asked Questions</a><br />
      </li>
            <li><a href="news-article.php?id=39" title="Version 3.5.16b of entrée is now available for download.">Version 3.5.16b of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=38" title="NECS reveals how the ELECTRONIC ORDER PAD links to your office data, as well as how entree.NET brings it all together via a graphical diagram. ">Roadmap to entree.NET and the ELECTRONIC ORDER PAD</a><br />
      </li>
            <li><a href="news-article.php?id=37" title="Version 3.5.16a of entrée is now available for download.">Version 3.5.16a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=36" title="Continuing our tradition of innovative new products using the latest technology, NECS is happy to announce our upcoming release of the "Electronic Order Pad" for the Apple iPad.  Click here for a "sneak peek" of some screen shots and more information...">Coming Soon... the ELECTRONIC ORDER PAD for the Apple iPad</a><br />
      </li>
            <li><a href="news-article.php?id=35" title="Version 3.5.16 of entrée is now available for download.">Version 3.5.16 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=32" title="Save 15% when you pre-order "entree.DOT", the Dot Foods interface, by April 8th.  This new software module automates procedures related to costs, pricing, purchasing and receiving, along with the ability to make your entire order guide from Dot Foods available to your customers.">Special Offer: 15% Discount when pre-ordering the Dot Foods Interface, entree.DOT</a><br />
      </li>
            <li><a href="news-article.php?id=34" title="Version 3.5.15 of entrée is now available for download.">Version 3.5.15 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=30" title="An update for the Ré3 Report System in the Version 3.5.14 and Version 3.5.14a releases of entrée is now available for download.">Ré3 Report System update is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=29" title="Version 3.5.14a of entrée is now available for download.">Version 3.5.14a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=28" title="Version 3.5.14 of entrée is now available for download. Please read this article for important additional information!">Version 3.5.14 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=27" title="Visit us at the Golbon Mid-Year Meeting & Buying Show, Dallas, TX, April 7th, 2011.">NECS at the Golbon Mid-Year Meeting & Buying Show</a><br />
      </li>
            <li><a href="news-article.php?id=26" title="Visit us at booth #984 at the Boston Seafood Show, in Boston, MA, March 20th - 22nd.  FREE Exhibit Hall entry to the show courtesy of NECS.">NECS at the Boston Seafood Show</a><br />
      </li>
            <li><a href="news-article.php?id=25" title="Version 3.5.13a of entrée is now available for download.">Version 3.5.13a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=24" title="Version 3.5.13 of entrée is now available for download.">Version 3.5.13 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=23" title="The NECS office will be closed for the holidays on Thursday, December 23rd, Friday, December 24th and Friday, December 31st.
However 24/7/365 technical support will remain available for those customers enrolled in that plan.">NECS Will Be Closed December 23rd, 24th and 31st.</a><br />
      </li>
            <li><a href="news-article.php?id=22" title="Version 1.1.16 of entrée.DSR is now available for download.">Version 1.1.16 of entrée.DSR is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=21" title="Version 3.5.12a of entrée is now available for download.  NOTE: This update only contains changes related to the entrée.NET add-on so only distributors using .NET will need this release.">Version 3.5.12a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=20" title="Version 3.5.12 of entrée is now available for download.  ">Version 3.5.12 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=19" title="Version 3.5.11a of entrée is now available for download.  NOTE: This update only contains changes related to the entrée.NET add-on so only distributors using .NET will need this release.">Version 3.5.11a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=18" title="Version 3.5.11 of entrée is now available for download.  NOTE: This update only contains changes related to the entrée.NET add-on so only distributors using .NET will need this release.">Version 3.5.11 of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=17" title="The popularity of our entree.NET system, the growing amount of customers using the system, and the high number of daily transactions, have prompted us to upgrade our servers and move to a more robust server farm which can accommodate our growth now and into the future.  This maintenance is scheduled for Sunday, November 28th, 2010 beginning at 8:00AM EST and running for approximately 8 hours.">entree.NET Scheduled Maintenance for Sunday, 11/28/10</a><br />
      </li>
            <li><a href="news-article.php?id=16" title="Version 2.0.5c of the entrée Host is now available for download">entrée Host 2.0.5c available</a><br />
      </li>
            <li><a href="news-article.php?id=14" title="entrée Host 2.0.5b available for download">entrée Host 2.0.5b available</a><br />
      </li>
            <li><a href="news-article.php?id=13" title="NECS is happy to announce that we've launched our new web site on Friday, October 22nd.  ">NECS Launches New Web Site</a><br />
      </li>
            <li><a href="news-article.php?id=10" title="Visit us at the IFDA 'Distribution Solutions Conference', in Tampa, FL, October 25-27, Booth #835 at the Tampa Convention Center.">NECS at the IFDA Distributions Solutions conference.</a><br />
      </li>
            <li><a href="news-article.php?id=12" title="Version 3.5.10a of entrée is now available for download ">Version 3.5.10a of entrée is now available!</a><br />
      </li>
            <li><a href="news-article.php?id=2" title="Version 3.5.9b of entrée is now available for download (click the "New Features" button above for highlights of the changes in this release)">Version 3.5.9b of entrée is now available!  <div style="width:1px;height:1px;overflow: hidden;"> <a href="http://www.travestix.info" title="travesti"</a><br />
      </li>
            <li><a href="news-article.php?id=3" title="Version 2.2.8 of entrée.UPC (bar code scanning) is now available for download">Version 2.2.8 of entrée.UPC </a><br />
      </li>
            <li><a href="news-article.php?id=9" title="entrée.PTV (Pass Through Value) released. Designed to handle the needs of distributors dealing with school systems.">entrée.PTV (Pass Through Value) released. </a><br />
      </li>
            <li><a href="news-article.php?id=4" title="entrée.QB provides general ledger connectivity features that unite both systems chart of accounts. It can release accounting data into multiple QuickBooks companies and export that data in a summary or detail format. ">NECS Integrates entrée Foodservice Distribution Software With QuickBooks </a><br />
      </li>
            <li><a href="news-article.php?id=6" title="NECS Integrates entrée Foodservice Distribution Software With QuickBooks Saves Time and Eliminates Data Entry Errors ">NECS Integrates entrée Foodservice Distribution Software With QuickBooks Saves Time and Eliminates Data Entry Errors </a><br />
      </li>
            <li><a href="news-article.php?id=7" title="NECS Announces Its New Version Of Entrée, Which Substantially Improves The Ability For Foodservice Distributors To Accept Orders Via The Internet">NECS Announces Its New Version Of Entrée, Which Substantially Improves The Ability For Foodservice Distributors To Accept Orders Via The Internet</a><br />
      </li>
            <li><a href="news-article.php?id=8" title="NECS announces low-cost software to automate small foodservice distribution operations.">NECS announces low-cost software to automate small foodservice distribution operations.</a><br />
      </li>
            <li><a href="news-article.php?id=5" title="ODBC driver for NECS software released. Will open up all NECS data files to other Windows applications.">ODBC driver for NECS software released. </a><br />
      </li>
            <li><a href="news-article.php?id=212" title=""></a><br />
      </li>
            <li><a href="news-article.php?id=215" title=""></a><br />
      </li>
          </ul>
  <br>
<br>
   <h2><b><a href="news.php">News</a>
    </b></h2>
  <ul type="disc">
    
           <li><a href="blog-article.php?id=49" title="Introducing the entrée V4 Dashboards. It is a business intelligence tool which provides snapshots of key performance indicators relevant to your operations. ">entrée Dashboards</a><br />
      </li>
            <li><a href="blog-article.php?id=48" title="Company President, Christopher Anatra, discusses Quantum Physics, the Mandela Effect and how that relates to perceived changes to your entree data files.">Quantum Physics, the Mandela Effect and perceived changes to your entree data</a><br />
      </li>
            <li><a href="blog-article.php?id=47" title="NECS outlines our Roadmap for 2019, providing our clients with an idea of what to expect for the upcoming year.">NECS Roadmap 2019</a><br />
      </li>
            <li><a href="blog-article.php?id=46" title="Industry Leader in ERP Software for Food Distributors Now Gives Customers Go-To Tool for Convenient and Efficient Mobile Food Ordering ">NECS, Inc. Launches entrée.EXPRESS Mobile Ordering App</a><br />
      </li>
            <li><a href="blog-article.php?id=45" title="NECS, Inc., Named to Food Logistics’ 2017 FL100+ Top Software and Technology Providers List">NECS, Inc., Named to Food Logistics’ 2017 FL100+ Top Software and Technology Providers List</a><br />
      </li>
            <li><a href="blog-article.php?id=44" title="Roadmap for the upcoming years of 2017- 2018 for NECS and our entrée software.">NECS 2017 - 2018 Road Map for entrée</a><br />
      </li>
            <li><a href="blog-article.php?id=43" title="NECS, Inc. Named a Top Software and Technology Partner by Food Logistics Magazine for the 7th Consecutive Year">NECS, Inc. Named a Top Software and Technology Partner by Food Logistics Magazine for the 7th Consecutive Year</a><br />
      </li>
            <li><a href="blog-article.php?id=41" title="On October 25th at our new offices in Branford, CT, NECS will be holding its first Partner Showcase Event.">Welcome to our Partners Showcase Event - October 25th - Branford, CT</a><br />
      </li>
            <li><a href="blog-article.php?id=40" title="NECS, Inc. Announces Technology Partnership and Integration with VistaTrac!">NECS, Inc. Announces Technology Partnership and Integration with VistaTrac!</a><br />
      </li>
            <li><a href="blog-article.php?id=39" title="Anoto Digital Pen Promotion ">Anoto Digital Pen Promotion </a><br />
      </li>
            <li><a href="blog-article.php?id=38" title="NECS attends the GS1 Connect 2016 Conference, June 1-3, Washington D.C. - Unlock the Power of Standards">NECS attends the GS1 Connect 2016 Conference, Washington D.C.</a><br />
      </li>
            <li><a href="blog-article.php?id=36" title="NECS on the road again, this time to St Louis for the annual Dot Food Show called Innovations 2016.">Innovations 2016 - Dot Foods Annual Trade Show</a><br />
      </li>
            <li><a href="blog-article.php?id=37" title="CIO Applications Recognizes NECS among 25 ERP Solutions Transforming Business 2016">CIO Applications Recognizes NECS among 25 ERP Solutions Transforming Business 2016</a><br />
      </li>
            <li><a href="blog-article.php?id=35" title="A review of our largest in-house training class for entree.
">Our Spring 2016 In House Training Class - Our Largest Ever!</a><br />
      </li>
            <li><a href="blog-article.php?id=31" title="Thoughts about the latest warehouse innovations from the Modex Show 2016 in Atlanta.">My Thoughts from the MODEX Show 2016</a><br />
      </li>
            <li><a href="blog-article.php?id=30" title="Announcing the 2016 “Food Logistics Champions: Rock Stars of the Supply Chain”">Announcing the 2016 “Food Logistics Champions: Rock Stars of the Supply Chain”</a><br />
      </li>
            <li><a href="blog-article.php?id=29" title="NECS acquires strategic assets from Cybershore, Inc.">NECS, Inc. to acquire strategic assets from Cybershore, Inc.</a><br />
      </li>
            <li><a href="blog-article.php?id=28" title="Madison, CT — December 23, 2015 — Food Logistics, the only publication dedicated exclusively to the global food and beverage supply chain, this week announced the twelfth annual FL100+ list, which appears in the November/December 2015 issue. For the sixth year running, NECS, Inc. was added to this list. ">NECS makes Annual FL100+ List 6th Year Running</a><br />
      </li>
            <li><a href="blog-article.php?id=27" title="Explanation for the new warehouse slotting features added to entrée V4, and What's happening at NECS in 2016.">Warehouse Slotting /  What's happening in 2016</a><br />
      </li>
            <li><a href="blog-article.php?id=23" title="Version 4.08 of entrée includes new "Auto-Complete" features in Create / Change Invoice. We are waiting on customer feedback before adding throughout the system.">New Auto-Complete features in Create / Change Invoice</a><br />
      </li>
            <li><a href="blog-article.php?id=22" title="New rates and information regarding Software Maintenance for entrée, new V4 Inventory File Maintenance features as well as the new Daily Summary dashboard">New Software Maintenance rates / New Inventory Features / Daily Summary</a><br />
      </li>
            <li><a href="blog-article.php?id=21" title="My third VLOG (Video Blog)covers a preview of the new Cycle Count feature of entrée V4 SQL.">Video Blog #3 - V4 Cycle Counts</a><br />
      </li>
            <li><a href="blog-article.php?id=20" title="My second VLOG (Video Blog) covers a preview of the new Dashboards feature of entrée V4 SQL">Video Blog #2 - V4 Dashboards Preview</a><br />
      </li>
            <li><a href="blog-article.php?id=19" title="entrée V4 SQL release status and my first video blog covering the new Search Screens">entrée V4 SQL Release Status and my first Video Blog</a><br />
      </li>
            <li><a href="blog-article.php?id=18" title="Information you'll need for your entrée V4 SQL implementation plan.">Your V4 SQL Implementation Plan</a><br />
      </li>
            <li><a href="blog-article.php?id=17" title="A walk down memory lane showing how our menu structure has improved over the years.">Evolution of the NECS menu structure</a><br />
      </li>
            <li><a href="blog-article.php?id=16" title="This blog provides information regarding a new feature in the ELECTRONIC ORDER PAD which allows your DSR's to enter credits for customers.  It also discusses new website features we've added for entree.NET.">New Customer Credit Features in the ELECTRONIC ORDER PAD, New entree.NET Web Site Features and more...</a><br />
      </li>
            <li><a href="blog-article.php?id=13" title="The review of five items you need to understand before installing Version 4 SQL of entree.">Getting Ready for entree Version 4 SQL</a><br />
      </li>
            <li><a href="blog-article.php?id=12" title="Welcome to "Part 4" of my Blog posting about our new ELECTRONIC WAREHOUSE MANAGER app!">ELECTRONIC LOADING SHEET becomes the ELECTRONIC WAREHOUSE MANAGER - Part 4</a><br />
      </li>
            <li><a href="blog-article.php?id=11" title="Review of new features added to entree.NET and the ELECTRONIC ORDER PAD.">New entree.NET and ELECTRONIC ORDER PAD features</a><br />
      </li>
            <li><a href="blog-article.php?id=10" title="The 12 enhancements planned for entree Version 4, project: Red Velvet Cupcake.">NECS entree Version 4 Feature / Ingredient List</a><br />
      </li>
            <li><a href="blog-article.php?id=9" title="The next release of entree.NET (due out in 4-6 weeks) will include our new Language Translator feature.">Introducing the Language Translator</a><br />
      </li>
            <li><a href="blog-article.php?id=8" title="Feature #1 - SQL databases via Sybase">Project Red Velvet Cupcake - entree Version 4</a><br />
      </li>
            <li><a href="blog-article.php?id=7" title="Testing active option">Testing active option</a><br />
      </li>
            <li><a href="blog-article.php?id=5" title="Photo Blog of the ELS in use at George's Seafood, Virginia">ELECTRONIC LOADING SHEET - Part 3</a><br />
      </li>
            <li><a href="blog-article.php?id=4" title="Explanation for displaying of customer "Add-Ons" to orders and the multi-scanner capability.">ELECTRONIC LOADING SHEET - Part 2</a><br />
      </li>
            <li><a href="blog-article.php?id=3" title="Background of the development of the new ELECTRONIC LOADING SHEET application, along with an explanation of how it works.">Development of the ELECTRONIC LOADING SHEET</a><br />
      </li>
            <li><a href="blog-article.php?id=42" title=""></a><br />
      </li>
          </ul>   
  </li>

      </ul>

    </p>

</ul></td><td width="41%" align="left" valign="top">
  <ul type="disc">
    <li> 
      <h2><b><a href="entree_food_distribution_software/" title="entrée - Organic Food Distribution Software">entrée</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="ap/" title="entrée.AP - Accounts Payable - Food Distribution Software">entrée.AP</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="doc/" title="entrée.DOC - Document Scanning Software - Food Distribution Software">entrée.DOC</a></b><br />
          </h2>
    </li>
       <li> 
      <h2><b><a href="dot/" title="DOT Foods Interface Software">entrée.DOT</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="dsr/" title="entrée.DSR - Salesperson Sofware - Food Distribution Software">entrée.DSR</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="edi/" title="entrée.EDI - Communication Software for the Food Industry">entrée.EDI</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="fs/" title="entrée.FS - Food Show Software for the Food Industry">entrée.FS</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="gl/" title="entrée.GL - General Ledger Food Distribution Software">entrée.GL</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="mw/" title="entrée.MW - Software for Organic Food Distributors">entrée.MW</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="net/" title="entrée.NET - Food Distribution Website">entrée.NET</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="ptv/" title="Pass Through Value - Software for Food Distributors">entrée.PTV</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="qb/" title="entrée.QB - Quickbooks Food Distribution Software">entrée.QB</a></b><br />
      </h2>
    </li>
    <li> 
      <h2><b><a href="upc/" title="Barcode Scanning - Food Distribution Software">entrée.UPC</a></b><br />
      </h2>
    </li>
           <li> 
        <h2><b><a href="orderpad/" title="Electronic Order Pad, iPad Order Entry Application, Mobile order entry">Electronic Order Pad</a></b><br />
        </h2>
    
           </li>      <li> 
        <h2><b><a href="ewm/" title="Electronic Warehouse Manager">Electronic Warehouse Manager</a></b><br />
        </h2>
    
           </li>
  </ul>
  
  </td></tr></table>

			<div class="divide30"></div>


		</section><!-- END OF CONTAINER -->
	</section><!-- END OF CONTENT -->

 	</section> <!-- END OF MAIN CONTENT HERE -->

		<footer>
			<section class="footer">
				<!-- A SPECIAL FOOTER FOR 4 - 8 SPAN LEFT SIDE !! -->

				
			  <div class="container" style="background-color: #cccccc;">
					<div class="row">

						<!-- SIMPLE ABOUT TEXT BLOCK -->
						<article class="span3">
						<h3 class="widget-title nobottommargin"><img src="images/logo_new.png" /></h3>
							<div class="divide10"></div>
							<p>NECS began in 1987 with the sole mission to produce top quality software for foodservice distributors.  Distributors who run their operations with our Windows based <strong>entr&eacute;e</strong> software are more profitable and operate more efficiently on reduced staffs. We have an enthusiastic user base who readily recommend <strong>entr&eacute;e</strong> to other wholesale food distributors.</p>
					  </article>

						<!-- ADDRESS BLOCK WIDGET-->
						<article class="span2">
							<h3 class="widget-title nobottommargin">GET IN TOUCH</h3>
							<div class="divide30"></div>
							<div class="table nobottommargin">
								<div class="table-cell top"><i class="icon-location-1 small black"></i></div>
								<div class="table-cell">
									<h3 class="widget-title">ADDRESS</h3>
										<p class="small italic">322 East Main Street<br />

3rd Floor<br />

Branford, CT. 06405</p>
							
								</div>
							</div>

							<div class="divide25"></div>
							<div class="table">
								<div class="table-cell top"><i class="icon-mobile small black"></i></div>
								<div class="table-cell">
									<h3 class="widget-title">PHONE</h3>
                                    <table width="100%" style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
                                    <tr>
                                    <td width="36%" style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
									<p class="small italic">Toll Free:</p></td><td width="64%"  style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" ><p class="small italic"> 800.766.6327</p>
                                    </td>
                                    </tr>
                                    <tr>
                                    <td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
                                    <p class="small italic">Local:</p></td><td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" ><p class="small italic">475.221.8200</p>
                                    </td>
                                   </tr>
                                   <tr>
                                   <td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
                                    <p class="small italic">Fax:</p></td><td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" > <p class="small italic">203.208.0889</p>
                                    </td>
                                    </tr>
                                    </table>
								</div>
							</div>
<a href="http://www.softwareadvice.com/erp/necs-entree-profile/" target="_blank" add rel="nofollow" ><img src="images/5.png"width="150" height="100" alt="Software Advice Reviews of NECS entr�e Software" /></a>
						</article><!-- END OF ADDRESS BLOCK WIDGET -->

						<!-- THE RECENT POSTS WIDGET -->
						<article class="span3">
							<h3 class="widget-title nobottommargin"><a href="blog.php">RECENT POSTS</a></h3>
							<div class="divide30"></div>

							<!-- A RECENT POSTS -->
							<section class="recent-posts-wrapper">
                            
                              
								<!-- A RECENT POST -->
								<div class="recent-post">
									<h4 class="recent-post-title nobottommargin"><a href="blog-article.php?id=49"><strong>entrée Dashboards</strong></a></h4>
									<div class="divide5"></div>
									<span class="small italic postdate">Jul 02 2020</span>
								</div><!-- END OF RECENT POST -->

								<div class="divide30"></div>
 
								<!-- A RECENT POST -->
								<div class="recent-post">
									<h4 class="recent-post-title nobottommargin"><a href="blog-article.php?id=48"><strong>Quantum Physics, the Mandela Effect and perceived changes to your entree data</strong></a></h4>
									<div class="divide5"></div>
									<span class="small italic postdate">Jun 03 2019</span>
								</div><!-- END OF RECENT POST -->

								<div class="divide30"></div>
 
								<!-- A RECENT POST -->
								<div class="recent-post">
									<h4 class="recent-post-title nobottommargin"><a href="blog-article.php?id=46"><strong>NECS, Inc. Launches entrée.EXPRESS Mobile Ordering App</strong></a></h4>
									<div class="divide5"></div>
									<span class="small italic postdate">Jul 19 2018</span>
								</div><!-- END OF RECENT POST -->

								<div class="divide30"></div>
  
								

							</section><!-- END OF RECENT POSTS WRAPPER -->



						</article><!-- END OF RECENT POSTS FOOTER WIDGET-->

						<article class="span4">
							<h3 class="widget-title nobottommargin"><a href="http://www.youtube.com/necsentreesoftware">ENTR&Eacute;E V4 SQL: THE LATEST GENERATION IN FOOD DISTRIBUTION SOFTWARE</a></h3>
							<div class="divide10"></div>
							<ul class="flickr feed"></ul>
												  <iframe width="335" height="315" src="//www.youtube.com/embed/zslV6Dpc6tQ" frameborder="0" allowfullscreen></iframe>
						</article>
					</div>
				</div>
			</section>


			<section class="subfooter">
				<div class="container">
					<div class="two_third">
						<p class="small">  <strong>Quick Nav: </strong><br />
						  <a  style="color: #cccccc !important;"  href="index.php" title="NECS Food Software for Distributors">Home</a> | <a  style="color: #cccccc !important;"  href="about.php" title="Food Distributor Software from NECS">About</a> | <a  style="color: #cccccc !important;"  href="testimonials.php" title="NECS ERP Software">Testimonials</a> | <a  style="color: #cccccc !important;"  href="news.php">News</a> | <a  style="color: #cccccc !important;"  href="blog.php">Blog</a> | <a  style="color: #cccccc !important;"  href="contact.php">Contact</a> | <a  style="color: #cccccc !important;"  href="support/">Support Login</a> | <a  style="color: #cccccc !important;"  href="training.php">Training</a><br />
						  <a  style="color: #cccccc !important;"  href="calendar.php">Event Calendar</a> | <a  style="color: #cccccc !important;"  href="docsearch.php">Document Samples</a> | <a  style="color: #cccccc !important;"  href="remotesupport.php">Remote Support</a> | <a  style="color: #cccccc !important;"  href="custom-programming.php">Custom Programming</a><br />
<br />

     <strong>Products: </strong><br />

    <a href="entree_food_distribution_software/" title="entr&eacute;e Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e V4</a> | 
      
    
     
     <a href="ap/" title="entr&eacute;e.AP - Accounts Payable - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.AP</a> |  
      
    
     
      <a href="doc/" title="entr&eacute;e.DOC - Document Scanning Software - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.DOC</a> |  
          
    
        
      <a href="dot/" title="DOT Foods Interface Software" style="color: #cccccc !important;">entr&eacute;e.DOT</a> |  
      
    
     
      <a href="dsr/" title="entr&eacute;e.DSR - Salesperson Sofware - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.DSR</a> |  
      
    
     
      <a href="edi/" title="entr&eacute;e.EDI - Communication Software for the Food Industry" style="color: #cccccc !important;">entr&eacute;e.EDI</a> |  
      
       <a href="express/" title="entr&eacute;e.EXPRESS" style="color: #cccccc !important;">entr&eacute;e.EXPRESS</a> |
     
      <a href="fs/" title="entr&eacute;e.FS - Food Show Software for the Food Industry" style="color: #cccccc !important;">entr&eacute;e.FS</a> |  
      
    
     
      <a href="gl/" title="entr&eacute;e.GL - General Ledger Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.GL</a> |  
      
    
     
      <a href="mw/" title="entr&eacute;e.MW - Software for Organic Food Distributors" style="color: #cccccc !important;">entr&eacute;e.MW</a><br /> 
      
    
     
      <a href="net/" title="entr&eacute;e.NET - Food Distribution Website" style="color: #cccccc !important;">entr&eacute;e.NET</a> |  
      
    
     
      <a href="ptv/" title="Pass Through Value - Software for Food Distributors" style="color: #cccccc !important;">entr&eacute;e.PTV</a> |  
      
    
     
      <a href="qb/" title="entr&eacute;e.QB - Quickbooks Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.QB</a> |  
      
    
     
      <a href="upc/" title="Barcode Scanning - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.UPC</a> |  
      
    
            
        <a href="orderpad/" title="Electronic Order Pad, iPad Order Entry Application, Mobile order entry" style="color: #cccccc !important;">Electronic Order Pad</a> |  
        
    
                  
        <a href="ewm/" title="Electronic Warehouse Manager" style="color: #cccccc !important;">Electronic Warehouse Manager</a></p>
				  </div>

		

					<div class="one_third lastcolumn">
				<div class="rightfloat">
				  <!-- SOCIALS -->          

<p class="small" >
C 2018 NECS, Inc. All Rights Reserved.<br />

<a href="sitemap.php" title="NECS.com Sitemap" style="color: #CCCCCC !important;">Sitemap</a>
					
	</p>
<a href="http://www.softwareadvice.com/erp/necs-entree-profile/" target="_blank" add rel="nofollow" ><img src="../images/content/01-gray-see-reviews.png" width="125" style="margin-top:7px; border: 2px solid #000 !important;"></a></div>
					</div>
					<div class="clear"></div>
				</div>
			</section>

		</footer>
	</section><!-- THE END OF THE BOXED WRAPPER -->

    <!-- javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

	<!-- Load the Bootstrap JS files -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

	<!-- Swipe Function on the 2nd Gallery in Home.html -->
	<script type="text/javascript" src="js/jquery.overscroll.min.js"></script>

	<!-- Basic ThemePunch Plugin Helpers -->
	<script type="text/javascript" src="js/jquery.themepunch.plugins.min.js"></script>

	<!-- INCLUDE THE MEGAFOLIO BANNER -->
	<!--<script type="text/javascript" src="megafolio/js/jquery.themepunch.megafoliopro.js"></script>-->

	<!-- FANCYBOX FOR MEGAFOLIO -->
<!--	<script type="text/javascript" src="megafolio/fancybox/jquery.fancybox.pack.js?v=2.1.3"></script>-->

	<!-- Optionally add helpers - button, thumbnail and/or media ONLY FOR ADVANCED USAGE-->
<!--	<script type="text/javascript" src="megafolio/fancybox/helpers/jquery.fancybox-media.js?v=1.0.5"></script>-->

	<!-- INCLUDE THE SHOWBIZ SCRIPT HERE -->
	<script type="text/javascript" src="js/jquery.themepunch.showbizpro.js"></script>

	<!-- TWITTER INCLUDS -->
	<script type="text/javascript" src="js/twitter.min.js"></script>

	<!-- SCROLLPLANE IMPORT -->
	<script type="text/javascript" src="js/jquery.jscrollpane.min.js"></script>

	<!-- the mousewheel plugin - optional to provide mousewheel support -->
	<script type="text/javascript" src="js/jquery.mousewheel.js"></script>

	<script type="text/javascript" src="js/jquery.fh.portfolio.js"></script>

	<!-- GOOGLE MAP -->
	<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=false"></script>
	<script type="text/javascript" src="js/jquery.gmap.js"></script>

	<!-- RETINA READY FUNCTIONS IN HTML DOCUMENTS -->
	<script type="text/javascript" src="js/retina.js" ></script>

	<!-- MEDIA RESIZERS -->
	<script type='text/javascript' src='js/mediaelement-and-player.min.js'></script>
	<script type='text/javascript' src='js/FitVids.js'></script>

	<!-- SOCIAL HELPERS -->
	<script type="text/javascript" src="js/jquery.jribbble-0.11.0.ugly.js" ></script>
	<script type="text/javascript" src="js/jquery.dcflickr.1.0.js" ></script>

	<!-- FORMS FOR CONTACT -->
	<script type="text/javascript" src="js/forms.js" ></script>

	<!-- MAIN FUNCTIONS FOR THEME -->
	<script type="text/javascript" src="js/screen.js" ></script>
    	<!-- INCLUDE THE REVOLUTION SLIDER -->
	<script type="text/javascript" src="js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>



<script type="text/javascript">
//<![CDATA[
var DID=177460;
var pcheck=(window.location.protocol == "https:") ? "https://sniff.visistat.com/live.js":"http://stats.visistat.com/live.js";
document.writeln('<scr'+'ipt src="'+pcheck+'" type="text\/javascript"><\/scr'+'ipt>');
//]]>
</script>
<!--VISISTAT SNIPPET//-->


<script src="https://www.google-analytics.com/urchin.js"
type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-426634-1";
urchinTracker();
</script><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-15123112-14']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
  </body>
</html>
