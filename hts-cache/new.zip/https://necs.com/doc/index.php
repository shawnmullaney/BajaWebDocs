
<!DOCTYPE html>
<html lang="en">
<head>

<title>entrée.DOC - Distribution Food Software</title>
	<meta name="google-site-verification" content="6EPecHT21fVP6wo7ElzmWqRsBnMYnpibOd3wJPtH0RE" />
<META NAME="KEYWORDS" CONTENT="seafood distribution software,food distribution software,wholesale distribution software,meat distribution software,warehouse management software,food distribution software quickbooks integration,affordable software for food distribution">
<META NAME="Description" CONTENT="entrée Food Software: food wholesale distribution software, distribution inventory control, sales history, online sales, and more">
<meta name="DC.Title" content="www.NECS.com" />
<meta name="DC.Subject" content="food distribution software,wholesale distribution software,meat distribution software," />
<meta name="DC.Description" content="NECS Food Distribution Software" />
<meta name="DC.Coverage.PlaceName" content="Global" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!--meta http-equiv="X-UA-Compatible" content="IE=edge" /-->

    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="../css/bootstrap.css" rel="stylesheet">


	<!-- REVOLUTION SLIDER STYLE SETTINGS-->
	<link rel="stylesheet" type="text/css" href="../js/rs-plugin/css/settings.css" media="screen" />


	 <!-- get jQuery from the google apis -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.js"></script>
    



	<!-- Modifications of StyleSheet  -->
	<link href="../css/style.css" rel="stylesheet" type="text/css">

	<!-- THE ICON FONTS -->
	<link rel="stylesheet" href="../css/type/fontello.css">

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="../favicon.ico?v=2">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">

	<!-- LOAD THE GOOGLE FONT -->
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800,400italic' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Lato:300,400,700,800,900,400italic' rel='stylesheet' type='text/css'>

<script type='text/javascript' src='swfobject.js'></script>
  </head>


<!-- ADD class="boxedlayout" IN CASE THE SITE SHOULD BE BOXED -->
  <body class="boxedlayout orange bg9">


	  	<!-- THE RESPONSIVE MENU ON THE TOP -->
		<div class="responsive_wrapper">
			<div id="responsive-menu">
				<div class="resp-closer"><i class="txt-center icon-cancel-1 white medium lm10 tm10"></i></div>
				<div class="resp-menuheader">NECS, Inc.</div>
				<ul>
                <li style="background: #f1f1f1; font-size:18px;"><a href="../index.php">Homepage</a></li>
                
                <li style="background: #f1f1f1; font-size:18px;">About</li>
                <li style="background: #ffffff;"><a href="../about.php">About NECS</a></li>
				<li style="background: #ffffff;"><a href="../testimonials.php">Testimonials</a></li>
				<li style="background: #ffffff;"><a href="../news.php">News</a></li>
                
                <li style="background: #f1f1f1; font-size:18px;">Desktop Applications</li>
                <li style="background: #ffffff;"><a href="../entree/">entr&eacute;e V4</a></li>
                <li style="background: #ffffff;"><a href="../ap/">entr&eacute;e.AP</a></li>
                <li style="background: #ffffff;"><a href="../doc/">entr&eacute;e.DOC</a></li>
                <li style="background: #ffffff;"><a href="../dot/">entr&eacute;e.DOT</a></li>
                <li style="background: #ffffff;"><a href="../edi/">entr&eacute;e.EDI</a></li>
                <li style="background: #ffffff;"><a href="../fs/">entr&eacute;e.FS</a></li>
                <li style="background: #ffffff;"><a href="../gl/">entr&eacute;e.GL</a></li>
                <li style="background: #ffffff;"><a href="../mw/">entr&eacute;e.MW</a></li>
                <li style="background: #ffffff;"><a href="../ptv/">entr&eacute;e.PTV</a></li>
                <li style="background: #ffffff;"><a href="../qb/">entr&eacute;e.QB</a></li>
                
                 <li style="background: #f1f1f1; font-size:18px;">Mobile Applications</li>
                 <li style="background: #ffffff;"><a href="../orderpad/">Electronic Order Pad</a></li>
                 <li style="background: #ffffff;"><a href="../ewm/">Electronic Warehouse Manager</a></li>
                 <li style="background: #ffffff;"><a href="../dsr/">entr&eacute;e.DSR</a></li>
                  <li style="background: #ffffff;"><a href="../anoto/">entr&eacute;e.PEN</a></li>
                  
                      <li style="background: #ffffff;"><a href="../pod/">entr&eacute;e.POD</a></li>
                 <li style="background: #f1f1f1; font-size:18px;">Internet Applications</li>
                 <li style="background: #ffffff;"><a href="../net/">entr&eacute;e.NET</a></li>
                 
                 <li style="background: #f1f1f1; font-size:18px;">Websites and Catalogs</li>
                 <li style="background: #ffffff;"><a href="../website-for-food-distributors/">entr&eacute;e.NET Website & Catalog</a></li>
                 
                  <li style="background: #f1f1f1; font-size:18px;">Support</li>
                 <li style="background: #ffffff;"><a href="../support/">Customer Login</a></li>
<li style="background: #ffffff;"><a href="http://manage.necs.com" target="_blank">Pay a Bill</a></li>
<li style="background: #ffffff;"><a href="../emergency/">Emergency 24H Support</a></li>
<li style="background: #ffffff;"><a href="../ios13.php" target="_blank">iOS 13</a></li>
																<li style="background: #ffffff;"><a href="../training.php">Training</a></li>
																<li style="background: #ffffff;"><a href="../calendar.php">Event Calendar</a></li>
                                                                  <li style="background: #ffffff;"><a href="../docsearch.php">Document Samples</a></li>
																<l style="background: #ffffff;"i><a href="../custom-programming.php">Custom Programming</a></li>
                                                                <li style="background: #ffffff;"><a href="../remotesupport.php">Remote Support</a></li>
                  
                   <li style="background: #f1f1f1; font-size:18px;"><a href="../blog.php"/>Blog</a></li>   
                     <li style="background: #f1f1f1; font-size:18px;"><a href="../press.php"/>Press Release</a></li>   
                    <li style="background: #f1f1f1; font-size:18px;"><a href="../partners/"/>Partners</a></li>
                    
                    <li style="background: #f1f1f1; font-size:18px;"><a href="../contact.php"/>Contact</li>   
                     <li style="background: #f1f1f1; font-size:18px;"><a href="../calendar.php"/>Calendar</li>  
                     <li><a href="../job-opportunities.php" class=""  style="color: #000000 !important;">Employment</a></li>       
				</ul>
			</div>
		</div>

	<!-- THIS IS THE WRAPPER FOR THE FULL TEMPLAGE -->
	<section class="boxed-wrapper">

		<!-- THE STICKY MENU AT THE TOP  -->
		<header class="header">

			<!-- THE SUB HEADER PAT -->
			 <section class="subheader_wrapper">
					<div class="container">
						<div class="subheader-left one_half nobottommargin">
							<p class="small lh35"><a href="https://www.necs.com/" /><img src="https://www.necs.com/images/256.png" width="75" style="margin-bottom: 0px; margin-top:5px; margin-right: 9px; width: 75px !important;"/></a><strong>Software for Food Distributors</strong>     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><a href="../emergency/" style="color: #25a114 !important; font-size:13px !important;">ACCESS OUR EMERGENCY 24 HOUR SUPPORT</a></strong>                                           
						  </p>
				  </div>
                        
							<div class="subheader-right one_half lastcolumn">
							
				<div style="float: right; margin-top:2px;">		<font style="font-size:14px; font-weight:bold; font-color: #f00000; margin-right: 35px; ">Toll Free: <strong>800.766.6327</strong> &nbsp;&nbsp;&nbsp;<div class="phone-spacer"></div> Local: <strong>475.221.8200</strong></font> 	<a href="../calendar.php" title="View the NECS Calendar"><img src="https://necs.com/images/cal-icon.jpg" height="26" style="height:26px !important;"/></a>			
<a href="https://www.facebook.com/pages/NECS-Inc/186969234681982" target="_blank" title="Visit the NECS, Inc. Facebook Page"><img src="../images/content/socialicons/fb.jpg"></a>


&nbsp;<a href="https://www.youtube.com/channel/UC-9mkS7A5XozBMb_OBHS8_g" target="_blank"  title="Visit the NECS, Inc. Youtube Channel"><img src="../images/content/socialicons/yt.jpg"></a>







</div>
						</div>
                        

						<div class="clear"></div>
                        
						<div class="divide20 visible-phone"></div>
					</div>
			</section><!-- END OF SUBHEADER WRAP -->



			<!-- THE HEADER WRAP -->
			<section class="header_wrapper">
				<div class="container" style="height: 95px !important; margin: 0px !important; margin-top: 0px !important;">
					<div class="row" >
							<!-- THE LOGO HOLDER -->
							<div class="span2" style="height: 65px !important;">
								<div class="logoholder" style="margin: 0px !important;">
									<a href="../index.php"><img src="../images/logo_new.png" alt="" style="max-width: none !important; height: 80px !important; margin-top: 6px !important;"></a>
								</div>
							</div>
							<!-- END OF LOGO HOLDER -->

							<!-- THE NAVIGATION HOLDER -->
							<div class="span10">
								<div id="nav" class="hidden-phone">
												<ul class="hide-nav">
													<li><a href="../index.php" class="" style="color: #000000 !important;">Home</a></li>


														<li><span class="hassubmenu toplevel"><a href="../about.php"  style="color: #000000 !important;">About</a></span>
															<ul>
																<li ><a href="../about.php">About NECS</a></li>
                                                                   
																<li><a href="../news.php">News</a></li>
                                                                 <li><a href="../press.php">Press Release</a></li>
                                                                <li><a href="../testimonials.php">Testimonials</a></li>
                                                               
															</ul>
												  </li>

														<li><span class="hassubmenu toplevel"><a href="../entree/"  style="color: #000000 !important;">Products</a></span>
																																					<ul style="width: 778px !important;position:absolute; left:-200px;  min-width: 778px !important;" width="778">

<li style="width: 255px !important; float: left;" class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important;  line-height:41px !important;"><strong>Desktop Applications</strong>
</a></li>


<li style="width: 255px !important; float: left; height: 41px !important;" class="main-menu-li"><a href="../"><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div>
 </a></li>


<li style="width: 255px !important; float: left;" class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important;  line-height:41px !important;"><strong>Mobile Applications</strong>
</a></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../entree_food_distribution_software/" title="Food Service Software entrée Food Distribution Software"><div class="inner-menu-item"><strong><font color="#000000">entrée V4:</font></strong></div> <br>
<span>ERP Software for Food Distributors</span></a></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="../ap/" title="Food Distribution Software Accounts Payable"><div class="inner-menu-item"><strong><font color="#000000">entrée.AP:</font></strong></div><br>
<span>
Accounts Payable</a></span></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="../orderpad/" title="Food Distribution Software Electronic Warehouse Manager"><div class="inner-menu-item"><strong><font color="#000000">Electronic Order Pad:</font></strong></div><br>
<span>
Order Entry & More for Your DSR's </a></span></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../doc/" title="entrée.DOC Document Scanning Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.DOC:</font></strong></div> <br>
<span>
Document Scanning</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../dot/" title="entrée.DOT Food Service Software - DOT Foods Interface"><div class="inner-menu-item"><strong><font color="#000000">entrée.DOT:</font></strong></div> <br>
<span>
The DOT Foods Interface</span></a></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="../ewm/" title="Food Distribution Software Electronic Warehouse Manager"><div class="inner-menu-item"><strong><font color="#000000">Electronic Warehouse Manager:</font></strong></div><br>
<span>
Receiving, Picking & more</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../edi/" title="entrée.EDI Electronic Data Interchange"><div class="inner-menu-item"><strong><font color="#000000">entrée.EDI:</font></strong></div> <br>
<span>
EDI Solutions for your Vendors/Customers</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../fs/" title="entrée.FS Food Show Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.FS:</font></strong></div> <br>
<span>
Food Show Software</a></span></li>

<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="../dsr/" title="Food Distribution Software DSR Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.DSR:</font></strong></div><br>
<span>
Laptop software for your DSRs </a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../gl/" title="entrée.GL General Ledger Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.GL:</font></strong></div> <br>
<span>General Ledger</a></span></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../mw/" title="entrée.MW Multiple Warehouse Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.MW:</font></strong></div> <br>
<span>
Multi Warehouse</a></span></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../pod/" title="Proof of Delivery" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">entrée.POD:</font></strong></div> <br>
<span>
Proof Of Delivery</a></span></li>




<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../ptv/" title="entrée.PTV Pass Through Value"><div class="inner-menu-item"><strong><font color="#000000">entrée.PTV:</font></strong></div> <br>
<span>
USDA "Pass Through Value" for Schools</a></span></li>

<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../qb/" title="entrée.QB QuickBooks Integrations Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.QB:</font></strong></div> <br>
<span>
QuickBooks Integration</a></span></li>



<li  style="width: 255px !important; float: left;" class="main-menu-li"><a href="../express/" title="Food Order Entry on Mobile Devices"><div class="inner-menu-item"><strong><font color="#000000">entrée.EXPRESS:</font></strong></div><br>
<span>
Fast Order Entry on Mobile Devices</a></span></li>

<li style="width: 255px !important; float: left; " class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important; line-height:41px !important;"><strong>Website & Online Catalog</strong>
</a></li>

<li style="width: 249px !important; float: left; border-bottom: 1px solid #ededed;  height: 41px !important;"><a href="../../" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div> 
 </a></li>

<li style="width: 255px !important; float: left;" class="main-menu-li" ><a style="color: #FF0000 !important; font-size:14px !important; line-height:41px !important;"><strong>Internet Applications</strong>
</a></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../website-for-food-distributors/" title="entrée.NET Websites for Food Distributors" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">entrée.NET Website with Catalog:</font></strong></div> <br>
<span>
Quality Websites and Product Catalog</a></span></li>


<li style="width: 249px !important; float: left; border-bottom: 1px solid #ffffff;"><a href="../../" class="menu-link"><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div> 
 </a></li>


<li style="width: 255px !important; float: left;" class="main-menu-li"><a href="../net/" title="entrée.NET Internet Ordering Software"><div class="inner-menu-item"><strong><font color="#000000">entrée.NET:</font></strong></div> <br>
<span>
Website/Internet Order Entry</a></span></li>
<!-- blank box
<li style="width: 249px !important; float: left; border-bottom: 1px solid #ffffff;"><a href="../"><div class="inner-menu-item"><strong><font color="#000000">&nbsp;</font></strong></div> 
 </a></li> -->


</ul>												</li>
<li><a href="../support/" class=""  style="color: #000000 !important;">Support</a><ul  style="width: 180px !important;">
<li><a href="../support/">Customer Login</a></li>
<li><a href="http://manage.necs.com" target="_blank">Pay a Bill</a></li>
<li><a href="../emergency/">Emergency 24H Support</a></li>
<li><a href="../faq/" target="_blank">FAQ</a></li>
<li><a href="../ios13.php">iOS 13</a></li>
																<li><a href="../training.php">Training</a></li>
																<li><a href="../calendar.php">Event Calendar</a></li>
                                                                  <li><a href="../docsearch.php">Document Samples</a></li>
																<li><a href="../custom-programming.php">Custom Programming</a></li>
                                                                <li><a href="../remotesupport.php">Remote Support</a></li>
															</ul></li>
<li><a href="../blog.php" class=""  style="color: #000000 !important;">Blog</a></li>
		<li><a href="../partners/" class=""  style="color: #000000 !important;">Partners</a></li>
														<li><a href="../contact.php" class=""  style="color: #000000 !important;">Contact</a></li>
                                                        <li><a href="../calendar.php" class=""  style="color: #000000 !important;">Calendar</a></li>

<li><span class="hassubmenu toplevel"><a href="../job-opportunities.php"  style="color: #000000 !important;">Employment</a></span>
															<ul>
																<li><a href="../job-opportunities.php">Job Opportunities</a></li>
                                                  
                                                               
															</ul>
												  </li>

 <img src="../images/spacer.png" width="150" style="height: 1px !important; width:150px !important;">
												</ul>
												<div class="clear"></div>

								</div><!-- END OF THE #NAV CONTAINER -->

							
							</div><!-- END OF NAVIGTION HOLDER -->
                            
						</div> <!-- END OF ROW -->
				</div> <!-- END OF CONTAINER -->
			</section> <!-- END OF HEADER WRAPPER  -->

	<div class="resp-navigator"><i class="icon-menu medium gray"></i></div>





</header>


		<!-- THE CONTENT -->
		<section class="maincontent">

	<!-- THE CONTENT -->
	<section>
		<section class="container">

			<!-- THE CONTENT HEADER -->

					<!-- THE MAIN INTRO TEXT -->
					<article>
						<div class="divide20"></div>
						<div class="row">
							<div class="span14">
								<h1 class="bigintro txt-left leftfloat rm20 nobottommargin red"><img src="../images/spacer.png" style="width: 295px !important; height: 15px !important; padidng: 0px!important; margin: 0px !important; line-height:0px !important;"/>   entrée.DOC: <font color="black">Document Scanning</font></h1>
								<br>

							
								<div class="clear"></div>
							</div>
						</div>

					
						<div class="divide2"></div>






			
			<div class="row">
			  <div class="span3" style="width: 280px !important;">
			  	<!-- AN ACCODION WIDGET - i.e. for SUBMENUS -->
					<article class="widget accordion-widget">


						<div class="accordion" id="accordion1">

							  <!-- ACCORDIONS ARE COLLECTED WITH GROUPS -->
							  <div class="accordion-group">

								 <!-- AN ACCORDION BUTTON WITH ICON, TEXT AND ">" -->
<div class="accordion-heading" style="background-color: #5ebd5e !important; ">
							      <a class="accordion-toggle" href="../contact.php?keyword=doc">

								    
								      <div class="leftfloat lm5"><p class="white mar8"><strong>Request More Information</strong></p></div>
								         <div class="rightfloat"><i class="icon-right-open white small"></i></div>
								   

							      </a></div>




 <div class="accordion-heading">
							      <a class="accordion-toggle" href="index.php">

								    
								      <div class="leftfloat lm5"><p class="red mar8"><strong>Overview</strong></p></div>
								   

							      </a></div>
                             
                                  <div class="accordion-heading">
                                     <a class="accordion-toggle">

								    
								      <div class="leftfloat lm5"><p class="red  mar8"><strong>Features</strong></p></div>
								      <div class="rightfloat"><i class="icon-right-open white small"></i></div>

							      </a></div> <!-- THE COLLAPSED PART OF TH ACCORDION -->
							
							 

							       <div class="accordion-inner">
							        <div class="leftfloat"><i class="icon-right-open maincolor small txt-left"></i></div>
							        <a href='#defining'  class="lm10 leftfloat mar8 tm6 black maincolor2"><strong>Defining Documents for Scanning</strong></p></a>
							        <div class="clear"></div>
							      </div>
     <div class="accordion-inner">
							        <div class="leftfloat"><i class="icon-right-open maincolor small txt-left"></i></div>
							        <a href='#viewing' class="lm10 leftfloat mar8 tm6 black maincolor2"><strong>Working With Scanned Documents</strong></p></a>
							        <div class="clear"></div>
							      </div>

							      

                                  
                                
                               
						
    </div>
				<!-- END OF COLLAPSED PART -->
                                  
                                  <div class="accordion-heading">
                                     <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapse1">

								
								      <div class="leftfloat lm5"><p class="red"><strong>System Requirements</strong></p></div>
								    

							      </a></div>
                                    <div class="accordion-inner" style="font-size:12px;">
							     <strong>entr&eacutee.DOC</strong> requires &nbsp;<strong><a href="../entree/" target="_blank" >entr&eacutee V3/V4</a></strong><br />

<strong>Scanner Requirements</strong>:<br />

Works with any TWAIN compatible sheet fed scanner

							           <div class="clear"></div>
					      </div>
                                 

							   


					   <!-- ACCORDIONS ARE COLLECTED WITH GROUPS -->
							 </div>
						<div class="clear"></div>
					</article>

			  </div><!-- END OF SPAN4 -->			  <div class="divide30 visible-phone"></div>
			  <div class="span9" style="width: 800px !important;">
			  <article class="fullwidth_img_container_small_440"  style="max-height:620px !important;">
			<a href="../images/content/doc/doc-top.jpg" target="_blank">	<img src="../images/content/doc/doc-top.jpg" style="width:100%;" alt=""></a>
			</article>
     <br>



						<h2 class="bm32"><strong>Solve Your Document Filing Issues</strong></h2>

				
						<p class="bm32">Foodservice distributors are faced with the challenge of  needing immediate access to important documents, such as signed customer  invoices. &nbsp;But the amount of time it takes to file these documents, store  them and then retrieve them when needed, takes up valuable time, warehouse  space and human resources.&nbsp; Using <strong>entrée.DOC</strong>, your documents can be  easily and instantly viewed while providing you with the option to print, fax  or email them as a PDF document.&nbsp; Documents which can be scanned and  stored electronically include signed customer invoices, customer checks,  purchasing documents, receiving documents, credit applications and others.  &nbsp;<a name="defining" id="defining"></a> </p>
			<h2 class="bm32"><strong>
    Defining Documents for Scanning</strong></h2>   
      <div class="span3" style="margin-left: 5px !important;"> <p>The <strong>entrée.DOC</strong> software has the ability to  automatically recognize documents and to whom they belong. This works for  loading sheets, invoices, customer checks, receiving documents, purchase orders  and other important documents.&nbsp; For example, when a driver returns from  making their deliveries, you can place a stack of signed invoices into the  sheet feeder of a scanner, and the <strong>entrée.DOC</strong> software will use its OCR  (Optical Character Recognition) abilities to determine the invoice number and  customer of that invoice. This is because it knows where on the form the  invoice number and customer number are located, and will automatically  associate the scanned document with the proper invoice, even when multiple  pages are involved.&nbsp; </p>
           </div>
             
 <div  class="span5">      <a href="../images/content/doc/DOC-1 Define Image ID.jpg" target="_blank"><img src="../images/content/doc/DOC-1 Define Image ID.jpg"  style="margin-right: 0px !important;"   width="450"></a>   
</div><div class="clear"></div>
<br>

               




   <br>
    <a name="viewing" id="viewing"></a> <h2 class="bm32"><strong>
Working With Scanned Documents</strong></h2>   
     <table><tr><td valign="top"> <p>Whenever you need to have access to the scanned document,  such as an invoice, it's always just a few mouse clicks away.&nbsp; Not only  can you view the full image scan on your screen, but you can also easily choose  to print, email or fax the document.&nbsp; When emailing a scanned document,  the <a href="../entree/" title="entree Food Distribution Software" /><strong>entrée</strong></a> system converts it to a PDF file for easy viewing.&nbsp; If  you use our <a href="../net" title="Online Ordering Distribution Software" /><strong>entrée.NET</strong></a> software for Internet based order entry, etc.,  your customers can view these scanned invoices themselves. &nbsp;Or if your  salespeople use the <a href="../orderpad/" title="Mobile Food Distribution Software" /><strong>Electronic Order Pad</strong></a>, they can view the scanned  invoice on their iPad at any time.&nbsp; The <a href="../net" title="Online Ordering Distribution Software" /><strong>entrée.NET</strong></a> and <a href="../orderpad" title="Mobile Food Distribution Software" /><strong>Electronic  Order Pad</strong></a> software will make scanned invoices available for up to 13  months. This is truly a time saving feature for your office, and one that your  customers and sales team will appreciate.</p>        </td> 
     </tr>
       <tr>
         <td valign="top"><a href="http://necs.com/anoto/featurepics/chg%20inv.png" target="_blank"><img src="http://necs.com/anoto/featurepics/chg%20inv.png"  style="margin-right: 0px !important;"></a></td>
       </tr>
     </table>      
    
    </div>
			</div>
			  </div><!-- END OF SPAN7 -->
			</div><!-- END OF ROW -->

			<div class="divide30"></div>
		</section><!-- END OF CONTAINER -->
	</section><!-- END OF CONTENT -->

 	</section> <!-- END OF MAIN CONTENT HERE -->

		<footer>
			<section class="footer">
				<!-- A SPECIAL FOOTER FOR 4 - 8 SPAN LEFT SIDE !! -->
				<div class="container" style="background-color: #cccccc;">
					<div class="row">

						<!-- SIMPLE ABOUT TEXT BLOCK -->
						<article class="span3">
						<h3 class="widget-title nobottommargin"><img src="../images/logo_new.png" /></h3>
							<div class="divide10"></div>
								<p>NECS began in 1987 with the sole mission to produce top quality software for foodservice distributors.  Distributors who run their operations with our Windows based <strong>entr&eacute;e</strong> software are more profitable and operate more efficiently on reduced staffs. We have an enthusiastic user base who readily recommend <strong>entr&eacute;e</strong> to other wholesale food distributors.</p>
					  </article>

						<!-- ADDRESS BLOCK WIDGET-->
						<article class="span2">
							<h3 class="widget-title nobottommargin">GET IN TOUCH</h3>
							<div class="divide30"></div>
							<div class="table nobottommargin">
								<div class="table-cell top"><i class="icon-location-1 small black"></i></div>
								<div class="table-cell">
									<h3 class="widget-title">ADDRESS</h3>
									<p class="small italic">322 East Main Street<br />

3rd Floor<br />

Branford, CT. 06405</p>
							
								</div>
							</div>

							<div class="divide25"></div>
							<div class="table">
								<div class="table-cell top"><i class="icon-mobile small black"></i></div>
								<div class="table-cell">
									<h3 class="widget-title">PHONE</h3>
                                    <table width="100%" style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
                                    <tr>
                                    <td width="36%" style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
									<p class="small italic">Toll Free:</p></td><td width="64%"  style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" ><p class="small italic">800.766.6327 </p>
                                    </td>
                                    </tr>
                                    <tr>
                                    <td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
                                    <p class="small italic">Local:</p></td><td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" ><p class="small italic">475.221.8200</p>
                                    </td>
                                   </tr>
                                   <tr>
                                   <td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" >
                                    <p class="small italic">Fax:</p></td><td style="border-collapse: collapse !important; border-top: none !important; height:14px !important; padding: 0px !important; margin-bottom: 0px !important;" > <p class="small italic">203.208.0889</p>
                                    </td>
                                    </tr>
                                    </table>
								</div>
							</div>
<a href="http://www.softwareadvice.com/erp/necs-entree-profile/" target="_blank" add rel="nofollow" ><img src="https://www.softwareadvice.com/erp/necs-entree-profile//theme/black/badge.png"width="150" height="100" alt="Software Advice Reviews of NECS entr�e Software" /></a>
						</article><!-- END OF ADDRESS BLOCK WIDGET -->

						<!-- THE RECENT POSTS WIDGET -->
						<article class="span3">
							<h3 class="widget-title nobottommargin"><a href="../blog.php">RECENT POSTS</a></h3>
							<div class="divide30"></div>

							<!-- A RECENT POSTS -->
							<section class="recent-posts-wrapper">
                            
                              
								<!-- A RECENT POST -->
								<div class="recent-post">
									<h4 class="recent-post-title nobottommargin"><a href="../blog-article.php?id=49"><strong>entrée Dashboards</strong></a></h4>
									<div class="divide5"></div>
									<span class="small italic postdate">Jul 02 2020</span>
								</div><!-- END OF RECENT POST -->

								<div class="divide30"></div>
 
								<!-- A RECENT POST -->
								<div class="recent-post">
									<h4 class="recent-post-title nobottommargin"><a href="../blog-article.php?id=48"><strong>Quantum Physics, the Mandela Effect and perceived changes to your entree data</strong></a></h4>
									<div class="divide5"></div>
									<span class="small italic postdate">Jun 03 2019</span>
								</div><!-- END OF RECENT POST -->

								<div class="divide30"></div>
 
								<!-- A RECENT POST -->
								<div class="recent-post">
									<h4 class="recent-post-title nobottommargin"><a href="../blog-article.php?id=46"><strong>NECS, Inc. Launches entrée.EXPRESS Mobile Ordering App</strong></a></h4>
									<div class="divide5"></div>
									<span class="small italic postdate">Jul 19 2018</span>
								</div><!-- END OF RECENT POST -->

								<div class="divide30"></div>
  
								

							</section><!-- END OF RECENT POSTS WRAPPER -->



						</article><!-- END OF RECENT POSTS FOOTER WIDGET-->

						<article class="span4">
							<h3 class="widget-title nobottommargin"><a href="https://www.youtube.com/necsentreesoftware">ENTR&Eacute;E V4 SQL: THE LATEST GENERATION IN FOOD DISTRIBUTION SOFTWARE</a></h3>
							<div class="divide10"></div>
							<ul class="flickr feed"></ul>
												  <iframe width="335" height="315" src="//www.youtube.com/embed/zslV6Dpc6tQ" frameborder="0" allowfullscreen></iframe>
						</article>
					</div>
				</div>
			</section>


			<section class="subfooter">
				<div class="container">
					<div class="two_third">
							<p class="small">  <strong>Quick Nav: </strong><br />
						  <a  style="color: #cccccc !important;"  href="../index.php" title="NECS Food Software for Distributors">Home</a> | <a  style="color: #cccccc !important;"  href="../about.php" title="Food Distributor Software from NECS">About</a> | <a  style="color: #cccccc !important;"  href="../testimonials.php" title="NECS ERP Software">Testimonials</a> | <a  style="color: #cccccc !important;"  href="../news.php">News</a> | <a  style="color: #cccccc !important;"  href="../blog.php">Blog</a> | <a  style="color: #cccccc !important;"  href="../contact.php">Contact</a> | <a  style="color: #cccccc !important;"  href="../support/">Support Login</a> | <a  style="color: #cccccc !important;"  href="../training.php">Training</a><br />
						  <a  style="color: #cccccc !important;"  href="../calendar.php">Event Calendar</a> | <a  style="color: #cccccc !important;"  href="../docsearch.php">Document Samples</a> | <a  style="color: #cccccc !important;"  href="../remotesupport.php">Remote Support</a> | <a  style="color: #cccccc !important;"  href="../custom-programming.php">Custom Programming</a><br />
<br />

     <strong>Products: </strong><br />

    <a href="../entree_food_distribution_software/" title="entr&eacute;e Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e V4</a> | 
      
    
     
     <a href="../ap/" title="entr&eacute;e.AP - Accounts Payable - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.AP</a> |  
      
    
     
      <a href="../doc/" title="entr&eacute;e.DOC - Document Scanning Software - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.DOC</a> |  
          
    
        
      <a href="../dot/" title="DOT Foods Interface Software" style="color: #cccccc !important;">entr&eacute;e.DOT</a> |  
      
    
     
      <a href="../dsr/" title="entr&eacute;e.DSR - Salesperson Sofware - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.DSR</a> |  
      
    
     
      <a href="../edi/" title="entr&eacute;e.EDI - Communication Software for the Food Industry" style="color: #cccccc !important;">entr&eacute;e.EDI</a> |  
                     
        <a href="../express/" title="entr&eacute;e.EXPRESS" style="color: #cccccc !important;">entr&eacute;e.EXPRESS</a> |
				

    
     
      <a href="../fs/" title="entr&eacute;e.FS - Food Show Software for the Food Industry" style="color: #cccccc !important;">entr&eacute;e.FS</a> |  
      
    
     
      <a href="../gl/" title="entr&eacute;e.GL - General Ledger Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.GL</a> |  
      
    
     
      <a href="../mw/" title="entr&eacute;e.MW - Software for Organic Food Distributors" style="color: #cccccc !important;">entr&eacute;e.MW</a><br /> 
      
    
     
      <a href="../net/" title="entr&eacute;e.NET - Food Distribution Website" style="color: #cccccc !important;">entr&eacute;e.NET</a> |  
      
    
     
      <a href="../ptv/" title="Pass Through Value - Software for Food Distributors" style="color: #cccccc !important;">entr&eacute;e.PTV</a> |  
      
    
     
      <a href="../qb/" title="entr&eacute;e.QB - Quickbooks Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.QB</a> |  
      
    
     
      <a href="../upc/" title="Barcode Scanning - Food Distribution Software" style="color: #cccccc !important;">entr&eacute;e.UPC</a> |  
      
    
            
        <a href="../orderpad/" title="Electronic Order Pad, iPad Order Entry Application, Mobile order entry" style="color: #cccccc !important;">Electronic Order Pad</a> |  
        
    
                  
        <a href="../ewm/" title="Electronic Warehouse Manager" style="color: #cccccc !important;">Electronic Warehouse Manager</a></p>
				  </div>

		

					<div class="one_third lastcolumn">
				<div class="rightfloat">
								<!-- SOCIALS -->          

<p class="small" >
C 2018 NECS, Inc. All Rights Reserved.<br />

							<a href="../sitemap.php" title="NECS.com Sitemap" style="color: #CCCCCC !important;">Sitemap</a>
							</p></div>
					</div>
					<div class="clear"></div>
				</div>
			</section>

		</footer>
	</section><!-- THE END OF THE BOXED WRAPPER -->

    <!-- javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

	<!-- Load the Bootstrap JS files -->
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>

	<!-- Swipe Function on the 2nd Gallery in Home.html -->
	<script type="text/javascript" src="../js/jquery.overscroll.min.js"></script>

	<!-- Basic ThemePunch Plugin Helpers -->
	<script type="text/javascript" src="../js/jquery.themepunch.plugins.min.js"></script>

	<!-- INCLUDE THE MEGAFOLIO BANNER -->
	<!--<script type="text/javascript" src="megafolio/js/jquery.themepunch.megafoliopro.js"></script>-->

	<!-- FANCYBOX FOR MEGAFOLIO -->
<!--	<script type="text/javascript" src="megafolio/fancybox/jquery.fancybox.pack.js?v=2.1.3"></script>-->

	<!-- Optionally add helpers - button, thumbnail and/or media ONLY FOR ADVANCED USAGE-->
<!--	<script type="text/javascript" src="megafolio/fancybox/helpers/jquery.fancybox-media.js?v=1.0.5"></script>-->

	<!-- INCLUDE THE SHOWBIZ SCRIPT HERE -->
	<script type="text/javascript" src="../js/jquery.themepunch.showbizpro.js"></script>

	<!-- INCLUDE THE REVOLUTION SLIDER -->
	<script type="text/javascript" src="../js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>

	<!-- TWITTER INCLUDS -->
	<script type="text/javascript" src="../js/twitter.min.js"></script>

	<!-- SCROLLPLANE IMPORT -->
	<script type="text/javascript" src="../js/jquery.jscrollpane.min.js"></script>

	<!-- the mousewheel plugin - optional to provide mousewheel support -->
	<script type="text/javascript" src="../js/jquery.mousewheel.js"></script>

	<script type="text/javascript" src="../js/jquery.fh.portfolio.js"></script>

	<!-- GOOGLE MAP -->
	<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=false"></script>
	<script type="text/javascript" src="../js/jquery.gmap.js"></script>

	<!-- RETINA READY FUNCTIONS IN HTML DOCUMENTS -->
	<script type="text/javascript" src="../js/retina.js" ></script>

	<!-- MEDIA RESIZERS -->
	<script type='text/javascript' src='../js/mediaelement-and-player.min.js'></script>
	<script type='text/javascript' src='../js/FitVids.js'></script>

	<!-- SOCIAL HELPERS -->
	<script type="text/javascript" src="../js/jquery.jribbble-0.11.0.ugly.js" ></script>
	<script type="text/javascript" src="../js/jquery.dcflickr.1.0.js" ></script>

	<!-- FORMS FOR CONTACT -->
	<script type="text/javascript" src="../js/forms.js" ></script>

	<!-- MAIN FUNCTIONS FOR THEME -->
	<script type="text/javascript" src="../js/screen.js" ></script>

<script type="text/javascript">
//<![CDATA[
var DID=177460;
var pcheck=(window.location.protocol == "https:") ? "https://sniff.visistat.com/live.js":"http://stats.visistat.com/live.js";
document.writeln('<scr'+'ipt src="'+pcheck+'" type="text\/javascript"><\/scr'+'ipt>');
//]]>
</script>
<!--VISISTAT SNIPPET//-->


<script src="https://www.google-analytics.com/urchin.js"
type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-426634-1";
urchinTracker();
</script><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-15123112-14']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

  </body>
</html>
